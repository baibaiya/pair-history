"""Replay the frozen 50,000-draw analysis in a temporary directory; no training."""
from pathlib import Path
import tempfile,shutil,subprocess,json
import pandas as pd
import numpy as np
R=Path(__file__).resolve().parents[1]
with tempfile.TemporaryDirectory(prefix='dual-token-focused-replay-') as dirname:
 w=Path(dirname)
 for p in (R/'focused_audit').iterdir():
  if p.is_dir():shutil.copytree(p,w/p.name)
  else:shutil.copy2(p,w/p.name)
 subprocess.run(['python',str(w/'scripts/bootstrap.py')],cwd=w,check=True)
 got=pd.read_csv(w/'INTERVAL_STABILITY.csv');want=pd.read_csv(R/'evidence/focused/INTERVAL_STABILITY.csv')
 keys=['section','seed','method','tag','reference','role','epoch','candidate_key','reference_key','condition','unit','metric']
 m=got.merge(want,on=keys,suffixes=('_new','_old'),validate='one_to_one');assert len(m)==len(want)==776
 cols=['relative_loss','new_low','new_high','upper_mc_low','upper_mc_high']
 maxerr=0.
 for c in cols:
  np.testing.assert_allclose(m[c+'_new'],m[c+'_old'],atol=2e-11,rtol=0)
  maxerr=max(maxerr,float(abs(m[c+'_new']-m[c+'_old']).max()))
 assert (m.new_confirmation_new==m.new_confirmation_old).all()
 result={'interval_rows_recomputed':len(m),'replicates':50000,'maximum_absolute_error':maxerr,'confirmation_decisions_identical':True,'model_training':False,'original_workspace_needed':False,'temporary_draws_removed':True}
(R/'focused_audit/REPLAY_CHECK.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
