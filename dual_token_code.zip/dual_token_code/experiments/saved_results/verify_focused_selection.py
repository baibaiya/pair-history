"""Reconstruct validation-only selection and measured timing from packaged trajectories."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
R=Path(__file__).resolve().parents[1];d=pd.read_csv(R/'evidence/focused/RESULTS_LONG.csv');rows=[];counts=0
for z in d.itertuples():
 p=R/'focused_audit/trajectories'/f'{z.seed}_{z.method}_{z.tag}'/'TRAJECTORY.jsonl'
 hist=[json.loads(l) for l in p.read_text().splitlines()]
 hits=[h for h in hist if h['metrics']['AP']>=z.target_AP and h['metrics']['BCE']<=z.target_BCE]
 assert bool(hits)==z.reached
 if hits:
  h=hits[0];assert h['epoch']==z.epoch
  np.testing.assert_allclose([h['process_seconds'],h['complete_seconds']],[z.process_seconds,z.complete_seconds],atol=1e-12,rtol=0)
 counts+=1
for key,g in d.groupby(['seed','method','reference']):
 hits=g[g.reached].sort_values(['process_seconds','multiplier','epoch'])
 selected=g[g.validation_selected]
 assert bool(len(hits))==bool(len(selected))
 if len(hits):assert len(selected)==1 and hits.iloc[0].tag==selected.iloc[0].tag
# Search charges all original and new trajectories once, irrespective of reference.
source=d.drop_duplicates(['seed','method','tag']);search=pd.read_csv(R/'evidence/focused/SEARCH_COST.csv')
for z in search.itertuples():
 s=source[(source.seed==z.seed)&(source.method==z.method)]
 np.testing.assert_allclose(s.full_search_component_seconds.sum(),z.all_three_search_seconds,atol=1e-9,rtol=0)
result={'configuration_reference_attainments_checked':counts,'configuration_selection_groups':len(search)*2,'all_trajectories':len(source),'selection_uses_validation_only':True,'search_charges_original_runs':True,'test_scores_not_used_by_this_check':True}
(R/'focused_audit/SELECTION_CHECK.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
