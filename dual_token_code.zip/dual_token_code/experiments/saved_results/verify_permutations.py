"""Replay all fixed permutation diagnostics from portable score/state inputs."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
from sklearn.metrics import average_precision_score
R=Path(__file__).resolve().parents[1]
f=json.loads((R/'evidence/PERMUTATION_SENSITIVITY_FREEZE.json').read_text())
meta=json.loads((R/'audit/PERMUTATION_INPUTS.json').read_text());z=np.load(R/'audit/permutation_inputs.npz');out=[]
for item in meta:
 k=item['instance'];q=z[k+'_q'];base=z[k+'_base'];pid=z[k+'_pid'];orig=z[k+'_codes'];centers=z[k+'_centers'];bins=z[k+'_bins'];y=z[item['dataset']+'_y'];gamma=float(z[k+'_gamma']);qa=average_precision_score(y,q);qb=np.mean(np.logaddexp(0,q)-y*q)
 for seed in f['seeds']:
  rng=np.random.default_rng(seed);codes=orig.copy()
  for b in np.unique(bins):
   ix=np.flatnonzero(bins==b);codes[ix]=orig[rng.permutation(ix)]
  off=np.where(codes>=0,centers[codes.clip(0)],0.);pred=base+gamma*off[pid]
  ap=average_precision_score(y,pred);bce=np.mean(np.logaddexp(0,pred)-y*pred)
  out.append(dict(**item,permutation_seed=seed,q4_AP=qa,shuffled_AP=ap,AP_advantage=qa-ap,q4_BCE=qb,shuffled_BCE=bce,BCE_advantage=bce-qb))
got=pd.DataFrame(out);want=pd.read_csv(R/'evidence/PERMUTATION_SENSITIVITY.csv');cols=['q4_AP','shuffled_AP','AP_advantage','q4_BCE','shuffled_BCE','BCE_advantage']
np.testing.assert_allclose(got[cols],want[cols],rtol=0,atol=1e-12)
print('Verified all',len(got),'fixed-predictor permutation comparisons.')
