from summarize import model_identity
from predictors import *
import pandas as pd
OLDROOT=ROOT.parent/'dual_token_submission_20261002'
def main():
 out=ROOT/'support';out.mkdir(exist_ok=False);recs=[];ident=[]
 for ds in SPLITS:
  rows,tr,vb,vs,vc,te=data(ds);y=rows[:,4];GLOBAL_PREVALENCE[0]=float(y[tr].mean());pairs,pid=np.unique(rows[:,:2].astype(int),axis=0,return_inverse=True)
  for seed in SEEDS:
   src=OLDROOT/'runs'/ds/str(seed)/'Q4';ep=json.loads((src/'SELECTED.json').read_text())['epoch'];cp=src/f'checkpoint_{ep}';raw=np.load(cp/'predictions.npz')['raw'];bt=calibrate(raw[vb],y[vb]);seen={}
   for draw in [2026100201,2026100202,2026100203]:
    order=sorted(tr,key=lambda i:hashlib.sha256(f'{draw}|{int(rows[i,0])}|{int(rows[i,1])}|{int(rows[i,2])}'.encode()).hexdigest());rank=np.empty(len(rows),int);count={}
    for i in order:rank[i]=count.get(pid[i],0);count[pid[i]]=rank[i]+1
    previous=set()
    for budget in [0,1,4,16,64,'all']:
     sub=np.sort(tr if budget=='all' else tr[rank[tr]<budget]);assert previous.issubset(set(sub));previous=set(sub);h=hashlib.sha256(sub.astype(np.int64).tobytes()).hexdigest();duplicate=h in seen
     dest=out/ds/str(seed)/str(draw)/str(budget);dest.mkdir(parents=True)
     n=np.bincount(pid[sub],minlength=len(pairs));meta=dict(dataset=ds,seed=seed,epoch=ep,draw=draw,budget=str(budget),support_sha256=h,duplicate=duplicate,duplicate_of=str(seen.get(h,'')),support_records=len(sub),covered_pairs=int((n>0).sum()),test_supported_fraction=float(np.mean(n[pid[te]]>0)),weight_sha256=model_identity(cp/'model.pt'),base_theta=bt.tolist())
     np.save(dest/'support_indices.npy',sub);dump(dest/'IDENTITY.json',meta);ident.append(meta)
     if duplicate:
      pred=np.load(seen[h]/'predictions.npz');pred={k:pred[k] for k in pred.files}
     else:
      pred={}
      for m in ['M0','M1','M2','M3']:
       z,st=construct(raw,rows,sub,vb,vc,m,bt);final,theta=finish(z,rows,vc);pred[m]=final;np.savez(dest/f'{m}_auxiliary.npz',**st,final_theta=theta)
      np.savez(dest/'predictions.npz',**pred);seen[h]=dest
     baseline=metrics(pred['M0'][te],y[te],rows[te]);floatmet=metrics(pred['M2'][te],y[te],rows[te])
     for m in pred:
      met=metrics(pred[m][te],y[te],rows[te]);recs.append(dict(**meta,method=m,**met,delta_AP=met['AP']-baseline['AP'],delta_BCE=met['BCE']-baseline['BCE'],delta_cell_P3=met['cell_P3']-baseline['cell_P3'],delta_cell_P10pct=met['cell_P10pct']-baseline['cell_P10pct'],q_minus_float_AP=met['AP']-floatmet['AP'] if m=='M3' else None,q_minus_float_BCE=met['BCE']-floatmet['BCE'] if m=='M3' else None))
   print('SUPPORT',ds,seed,flush=True)
 pd.DataFrame(recs).to_csv(ROOT/'SUPPORT_CURVES.csv',index=False);dump(ROOT/'SUPPORT_IDENTITIES.json',ident)
if __name__=='__main__':main()
