from core import *
from canonical_metrics import canonical_metrics as metrics

def construct(raw,rows,tr,vb,vc,method,base_theta=None):
 y=rows[:,4];theta=calibrate(raw[vb],y[vb]) if base_theta is None else base_theta
 base=theta[0]*raw+theta[1];st={'base_theta':theta};z=base
 if method in ('M1','M2','M3'):
  pairs,pid=np.unique(rows[:,:2].astype(int),axis=0,return_inverse=True);P=len(pairs);n=np.bincount(pid[tr],minlength=P)
  st.update(pairs=pairs,pid=pid,support=n)
  if method=='M1':
   # The global prevalence fallback is supplied from the full training population only at budget zero.
   gp=y[tr].mean() if len(tr) else float(GLOBAL_PREVALENCE[0]);s=np.bincount(pid[tr],weights=y[tr],minlength=P)
   taus=[1,4,16,64,256];priors={t:(s+t*gp)/(n+t) for t in taus};tau=min(taus,key=lambda t:metrics(rawlog(priors[t][pid[vb]]),y[vb])['BCE'])
   pr=rawlog(priors[tau]);X=np.column_stack((np.ones(len(rows)),base,pr[pid]))
   def fn(b):
    v=X[vb]@b;e=expit(v)-y[vb]
    return float(np.sum(np.logaddexp(0,v)-y[vb]*v)+.5*b@b),X[vb].T@e+b
   fit=minimize(fn,[0,1,0],jac=True,method='L-BFGS-B',options={'maxiter':1000,'ftol':1e-13,'gtol':1e-7})
   assert fit.success or np.linalg.norm(fit.jac)<1e-4
   z=X@fit.x;st.update(tau=tau,beta=fit.x,prior_logit=pr,global_prevalence=gp)
  else:
   v,n=continuous(pid[tr],y[tr],base[tr],P);st['continuous']=v
   if method=='M3' and len(tr):
    off,codes,centers=quantize(v,n,pid[tr],y[tr],base[tr],4);st.update(codes=codes,centers=centers)
   elif method=='M3':
    off=v;st.update(codes=np.full(P,-1,dtype=np.int16),centers=np.zeros(16))
   else:off=v
   z=base+off[pid]
 return z,st
GLOBAL_PREVALENCE=[None]

def finish(z,rows,vc):
 theta=calibrate(z[vc],rows[vc,4]);return theta[0]*z+theta[1],theta
