from core import *
import sys,importlib.util,torch,pandas as pd

def load_module(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m

def prepare(method,phase):
 t=time.perf_counter();rows,tr,vb,vs,vc,te=data('GDSC');I=STAGE/'GDSC_INPUTS';d=pd.read_csv(I/'drugs.csv',index_col=0);gene=pd.read_csv(I/'cells.csv',index_col=0);cell=gene.to_numpy(dtype=np.float32)
 D=dict(rows=rows,tr=tr,vb=vb,vs=vs,vc=vc,te=te)
 if method in ('M4','M5'):D.update(disease=np.load(I/'disease.npy'),interactions=np.load(I/'interactions.npy'))
 phase['file_read']=time.perf_counter()-t;t=time.perf_counter()
 from rdkit import Chem,DataStructs
 from rdkit.Chem import MACCSkeys
 maccs=[]
 for row in d.itertuples():
  a=np.zeros((1,),np.float32);DataStructs.ConvertToNumpyArray(MACCSkeys.GenMACCSKeys(Chem.MolFromSmiles(row.smiles)),a);maccs.append(a)
 D['maccs']=np.array(maccs,dtype=np.float32)
 if method not in ('M4','M5'):
  D['cell']=(cell-cell.mean(0,keepdims=True))/np.maximum(cell.std(0,keepdims=True),1e-6);phase['feature_processing']=time.perf_counter()-t;return D
 import deepchem as dc
 from drug_util import GraphDataset,collate,drug_feature_extract
 features=pd.DataFrame();ids=[];featurizer=dc.feat.ConvMolFeaturizer()
 for row in d.itertuples():
  mol=featurizer.featurize(Chem.MolFromSmiles(row.smiles))[0];features[str(int(row.CIDs))]=[mol.get_atom_features(),mol.get_adjacency_list()];ids.append(int(row.CIDs))
 phase['feature_processing']=time.perf_counter()-t;t=time.perf_counter()
 if method=='M5':
  from process_data import get_drug_feature_matrix
  drug=drug_feature_extract(features,ids);dataset=GraphDataset(graphs_dict=get_drug_feature_matrix(drug),drug_ids=ids)
 else:drug=drug_feature_extract(features);dataset=GraphDataset(graphs_dict=drug)
 graph=next(iter(torch.utils.data.DataLoader(dataset,collate_fn=collate,batch_size=len(drug),shuffle=False)))
 D.update(graph_x=graph.x,graph_edge_index=graph.edge_index,graph_batch=graph.batch,cell=cell)
 from similarity import get_Cosin_Similarity,get_pvalue_matrix
 if not hasattr(np,'mat'):np.mat=np.asmatrix
 D['sims']=[np.asarray(v,dtype=np.float32) for v in [get_Cosin_Similarity(maccs),get_pvalue_matrix(np.array(gene,dtype=np.float32)),get_pvalue_matrix(D['disease'])]]
 pos=rows[tr,:3][rows[tr,4]==1].astype(np.int64);ints=np.array(D['interactions'],dtype=np.int64)
 D['hs']=np.stack((pos.ravel(),np.repeat(np.arange(len(pos)),3)));D['hi']=np.stack((ints.ravel(),np.repeat(np.arange(len(ints)),2)));D['num_synergy']=len(pos);phase['graph_or_index']=time.perf_counter()-t
 return D

def imports(method):
 if method in ('M4','M5'):
  A=G/'official_repos'/('MoCo-MultiSynergy' if method=='M5' else 'HERMES');sys.path.insert(0,str(A/'Model'))
  if method=='M5':
   from model import Initializer,Refiner,Consolidator,MoCo_MultiSynergy
   cls=MoCo_MultiSynergy
  else:
   from HERMES.model import Initializer,Refiner,Consolidator,HERMERS
   cls=HERMERS
  from utils import TruncatedExponentialLR
  return Initializer,Refiner,Consolidator,cls,TruncatedExponentialLR
 return load_module('object_definition',G/'nci_almanac/quality_gap_execution_20260928/train.py').ObjectModel

if __name__=='__main__':
 import argparse
 a=argparse.ArgumentParser();a.add_argument('method');args=a.parse_args();m=args.method
 os.sched_setaffinity(0,{0});torch.set_num_threads(1);t=time.perf_counter();imports(m);p={};D=prepare(m,p);dest=ROOT/'cache';dest.mkdir(exist_ok=True);path=dest/f'{m}.pt';assert not path.exists();torch.save(D,path);dump(dest/f'{m}.json',dict(method=m,build_seconds=time.perf_counter()-t,phases=p,bytes=path.stat().st_size,sha256=sha(path),reuse='same fixed inputs/features and exact train split only; no learned state',contains='feature arrays, canonical population and split; graph structural indices and fixed similarity targets for graphs'))
