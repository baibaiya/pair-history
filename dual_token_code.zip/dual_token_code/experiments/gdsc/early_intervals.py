from summarize import model_identity
from predictors import *
import pandas as pd
OLDROOT=ROOT.parent/'dual_token_submission_20261002'

def ordered_ap(z,y):
 order=np.argsort(-z,kind='stable');zz=z[order];yy=y[order];ends=np.r_[np.flatnonzero(zz[1:]!=zz[:-1]),len(zz)-1]
 def calc(w):
  w=w[order];tp=np.cumsum(w*yy)[ends];total=np.cumsum(w)[ends]
  if not tp[-1]:return np.nan
  return float(np.sum(np.diff(np.r_[0,tp])*np.divide(tp,total,out=np.zeros_like(tp),where=total>0))/tp[-1])
 return calc

def boot(pred,y,rows,unit,draws):
 groups=np.unique(rows[:,:2] if unit=='pair' else rows[:,2:3],axis=0,return_inverse=True)[1];N=np.bincount(groups);P=len(N);rng=np.random.default_rng(20261002);weights=np.array([np.bincount(rng.integers(P,size=P),minlength=P) for _ in range(draws)],dtype=np.int16);out={};qs=list(queries(rows)['cell'].values())
 for key,z in pred.items():
  ap=ordered_ap(z,y);loss=np.bincount(groups,weights=np.logaddexp(0,z)-y*z,minlength=P);a=np.zeros((draws,4));a[:,1]=(weights@loss)/(weights@N)
  for b,w in enumerate(weights):a[b,0]=ap(w[groups].astype(float))
  # Pair resampling is a candidate multiset: duplicates retain multiplicity in the ranked list.
  numerator=np.zeros((draws,2));denom=np.zeros(draws)
  for ix in qs:
   ix=ix[np.lexsort((rows[ix,2],rows[ix,1],rows[ix,0]))];ix=ix[np.argsort(-z[ix],kind='stable')]
   if unit=='cell':
    w=weights[:,groups[ix[0]]];denom+=w
    for j,k in enumerate([min(3,len(ix)),max(1,int(np.ceil(.1*len(ix))))]):numerator[:,j]+=w*y[ix[:k]].mean()
   else:
    w=weights[:,groups[ix]];total=w.sum(1);cum=np.cumsum(w,axis=1);before=cum-w;denom+=(total>0)
    for j,k in enumerate([np.minimum(3,total),np.maximum(1,np.ceil(.1*total).astype(int))]):
     hits=(np.minimum(w,np.maximum(0,k[:,None]-before))*y[ix]).sum(1);numerator[:,j]+=np.divide(hits,k,out=np.zeros(draws),where=k>0)
  a[:,2:]=np.divide(numerator,denom[:,None],out=np.full_like(numerator,np.nan),where=denom[:,None]>0);out[key]=a
 return out,weights

def main():
 rows,tr,vb,vs,vc,te=data('GDSC');y=rows[:,4];pred={};ids=[];points=[];out=ROOT/'intervals';out.mkdir(exist_ok=False)
 for seed in SEEDS:
  for m in ['Q4','HERMES','MOCO']:
   src=OLDROOT/'runs/GDSC'/str(seed)/m;ep=100 if m=='Q4' else json.loads((src/'SELECTED.json').read_text())['epoch'];cp=src/f'checkpoint_{ep}';key=f'{seed}_{m}';pred[key]=np.load(cp/'predictions.npz')['final'][te];ids.append(dict(seed=seed,method=m,epoch=ep,weight_sha256=model_identity(cp/'model.pt'),prediction_sha256=sha(cp/'predictions.npz')));points.append(dict(seed=seed,method=m,epoch=ep,**metrics(pred[key],y[te],rows[te])))
 pd.DataFrame(points).to_csv(ROOT/'EARLY_POINTS.csv',index=False);dump(out/'IDENTITIES.json',ids);results=[];names=['AP','BCE','cell_P3','cell_P10pct']
 for unit in ['pair','cell']:
  draws,w=boot(pred,y[te],rows[te],unit,2000);np.savez_compressed(out/f'{unit}_draws.npz',**draws);np.savez_compressed(out/f'{unit}_indices.npz',multiplicities=w)
  for ref in ['HERMES','MOCO']:
   for seed in [*SEEDS,'fixed_three_model_mean']:
    seeds=SEEDS if isinstance(seed,str) else [seed];c=np.mean([draws[f'{s}_Q4'] for s in seeds],axis=0);r=np.mean([draws[f'{s}_{ref}'] for s in seeds],axis=0)
    cp=np.mean([[next(p for p in points if p['seed']==s and p['method']=='Q4')[k] for k in names] for s in seeds],axis=0);rp=np.mean([[next(p for p in points if p['seed']==s and p['method']==ref)[k] for k in names] for s in seeds],axis=0)
    for j,k in enumerate(names):
     rel=c[:,j]/r[:,j]-1 if k=='BCE' else 1-c[:,j]/r[:,j];loss=cp[j]/rp[j]-1 if k=='BCE' else 1-cp[j]/rp[j];lo,hi=np.nanquantile(rel,[.025,.975]);dl,dh=np.nanquantile(c[:,j]-r[:,j],[.025,.975]);results.append(dict(unit=unit,seed=seed,reference=ref,metric=k,candidate=float(cp[j]),reference_value=float(rp[j]),difference=float(cp[j]-rp[j]),relative_loss=float(loss),difference_low=float(dl),difference_high=float(dh),loss_low=float(lo),loss_high=float(hi),status_5pct='confirmed' if hi<=.05 else ('point_failure' if loss>.05 else 'inconclusive'),status_2pct='confirmed' if hi<=.02 else ('point_failure' if loss>.02 else 'inconclusive'),status_10pct='confirmed' if hi<=.1 else ('point_failure' if loss>.1 else 'inconclusive')))
  print('BOOTSTRAP',unit,flush=True)
 pd.DataFrame(results).to_csv(ROOT/'EARLY_INTERVALS.csv',index=False)
if __name__=='__main__':main()
