from predictors import *
import pandas as pd
OLDROOT=ROOT.parent/'dual_token_submission_20261002'
PRIMARY=['AP','BCE'];SCREEN=['cell_P3','partner_P3','cell_P10pct','partner_P10pct']
def passes(m,r,tol=.05,strict=False):return m['AP']>=(1-tol)*r['AP'] and m['BCE']<=(1+tol)*r['BCE'] and (not strict or all(m[k]>=(1-tol)*r[k] for k in SCREEN))
def oldref(seed,m):
 rows,tr,vb,vs,vc,te=data('GDSC');src=OLDROOT/'runs/GDSC'/str(seed)/m;ep=json.loads((src/'SELECTED.json').read_text())['epoch'];z=np.load(src/f'checkpoint_{ep}/predictions.npz')['final'];return ep,metrics(z[vs],rows[vs,4],rows[vs]),metrics(z[te],rows[te,4],rows[te])
def model_identity(p):
 if p.exists():return sha(p)
 sidecar=p.with_suffix(p.suffix+'.sha256');assert sidecar.exists(),p
 return sidecar.read_text().strip()

def main():
 rows,tr,vb,vs,vc,te=data('GDSC');curves=[];ttq=[];selected=[];chain=[];cost=[];refs=[];dense={};sparse={100,300,600,1000,1500,2000,2500,3000}
 for condition in ['COLD','REUSE']:
  for seed in SEEDS:
   for m in ['M0','M1','M2','M3','M4','M5']:
    src=ROOT/'runs'/condition/str(seed)/m;hist=[json.loads(l) for l in (src/'TRAJECTORY.jsonl').read_text().splitlines()];dense[condition,seed,m]=hist
    for h in hist:
     cp=src/f"checkpoint_{h['epoch']}";z=np.load(cp/'predictions.npz')['final'];test=metrics(z[te],rows[te,4],rows[te]);h['test']=test
     item=dict(condition=condition,seed=seed,method=m,epoch=h['epoch'],seconds=h['complete_seconds'],process_seconds=h['process_seconds'],**{f'phase_{k}':v for k,v in h['phase'].items()});curves.append(dict(**item,**h['metrics'],**{f'test_{k}':v for k,v in test.items()}));chain.append(dict(condition=condition,seed=seed,method=m,epoch=h['epoch'],seconds=h['complete_seconds'],weight_sha256=model_identity(cp/'model.pt'),auxiliary_sha256=sha(cp/'auxiliary.npz'),prediction_sha256=sha(cp/'predictions.npz'),trajectory_sha256=sha(src/'TRAJECTORY.jsonl')))
    sel=json.loads((src/'SELECTED.json').read_text());h=next(h for h in hist if h['epoch']==sel['epoch']);selected.append(dict(condition=condition,seed=seed,method=m,epoch=h['epoch'],seconds=h['complete_seconds'],**h['test']))
    for ref,rm in [('HERMES','M4'),('MOCO','M5')]:
     ep,target,testref=oldref(seed,ref);refs.append(dict(condition=condition,seed=seed,reference=ref,epoch=ep,**target))
     for tol in [.02,.05,.1]:
      for strict in [False,True]:
       for grid in ['dense','sparse_observed']:
        hs=hist if grid=='dense' else [h for h in hist if h['epoch'] in sparse];flags=[passes(h['metrics'],target,tol,strict) for h in hs];i=next((i for i,p in enumerate(flags) if p),None);hit=hs[i] if i is not None else None
        rec=dict(condition=condition,seed=seed,method=m,reference=ref,tolerance=tol,strict_screening=strict,grid=grid,reached=hit is not None,reference_epoch=ep,epoch=hit['epoch'] if hit else None,time_seconds=hit['complete_seconds'] if hit else None,process_seconds=hit['process_seconds'] if hit else None,maintained=all(flags[i:]) if hit else False,budget_seconds=hist[-1]['complete_seconds'],test_primary_pass=passes(hit['test'],testref,tol) if hit else False,test_strict_pass=passes(hit['test'],testref,tol,True) if hit else False)
        if hit:rec.update({f'test_{k}':hit['test'][k] for k in PRIMARY+SCREEN})
        ttq.append(rec)
        if tol==.05 and grid=='dense' and not strict and hit:cost.append(dict(condition=condition,seed=seed,method=m,reference=ref,epoch=hit['epoch'],complete_seconds=hit['complete_seconds'],process_seconds=hit['process_seconds'],common_import_startup_seconds=hit['process_seconds']-hit['complete_seconds'],other_measured_overhead_seconds=hit['complete_seconds']-sum(hit['phase'].values()),**hit['phase']))
 # New graph targets explicitly secondary.
 sensitivity=[]
 for condition in ['COLD','REUSE']:
  for seed in SEEDS:
   for ref,rm in [('HERMES','M4'),('MOCO','M5')]:
    hs=dense[condition,seed,rm];best=max(hs,key=lambda h:(h['metrics']['AP'],-h['epoch']));old_ep,target,_=oldref(seed,ref)
    for m in ['M0','M1','M2','M3','M4','M5']:
     hit=next((h for h in dense[condition,seed,m] if passes(h['metrics'],best['metrics'])),None);sensitivity.append(dict(condition=condition,seed=seed,method=m,reference=ref,old_reference_AP=target['AP'],dense_reference_AP=best['metrics']['AP'],dense_reference_epoch=best['epoch'],is_higher=best['metrics']['AP']>target['AP'],reached=hit is not None,epoch=hit['epoch'] if hit else None,time_seconds=hit['complete_seconds'] if hit else None))
 pd.DataFrame(curves).query('epoch == 100').to_csv(ROOT/'FIXED_100_MEASURED.csv',index=False);pd.DataFrame(curves).to_csv(ROOT/'VALIDATION_CURVES.csv',index=False);pd.DataFrame(selected).to_csv(ROOT/'SELECTED_TEST.csv',index=False);pd.DataFrame(ttq).to_csv(ROOT/'TIME_TO_QUALITY.csv',index=False);pd.DataFrame(cost).to_csv(ROOT/'COST_DECOMPOSITION.csv',index=False);pd.DataFrame(sensitivity).to_csv(ROOT/'DENSE_TARGET_SENSITIVITY.csv',index=False);dump(ROOT/'TIMING_PREDICTION_IDENTITIES.json',chain)
 df=pd.DataFrame(ttq)
 keys=['condition','seed','method','reference','tolerance','strict_screening']
 grid=df[df.grid=='dense'].merge(df[df.grid=='sparse_observed'],on=keys,suffixes=('_dense','_sparse'))
 grid['sparse_observed_minus_dense_seconds']=grid.time_seconds_sparse-grid.time_seconds_dense;grid.to_csv(ROOT/'GRID_EFFECT.csv',index=False)
 d=df[(df.tolerance==.05)&(~df.strict_screening)&(df.grid=='dense')];summary=[]
 for (condition,method,ref),g in d.groupby(['condition','method','reference']):
  baseline=d[(d.condition==condition)&(d.method==('M4' if ref=='HERMES' else 'M5'))&(d.reference==ref)].set_index('seed');savings=[];process_savings=[]
  for _,r in g.iterrows():
   b=baseline.loc[r.seed]
   if r.reached and b.reached:
    savings.append(1-r.time_seconds/b.time_seconds);process_savings.append(1-r.process_seconds/b.process_seconds)
  summary.append(dict(condition=condition,method=method,reference=ref,reached=int(g.reached.sum()),total=len(g),test_primary_pass=int(g.test_primary_pass.sum()),maintained=int(g.maintained.sum()),median_seconds=float(g.time_seconds.median()) if g.reached.all() else None,min_seconds=float(g.time_seconds.min()) if g.reached.all() else None,max_seconds=float(g.time_seconds.max()) if g.reached.all() else None,mean_paired_saving=float(np.mean(savings)) if len(savings)==len(g) else None,median_process_seconds=float(g.process_seconds.median()) if g.reached.all() else None,mean_paired_process_saving=float(np.mean(process_savings)) if len(process_savings)==len(g) else None,test_AP_mean=float(g.test_AP.mean()) if g.reached.all() else None,test_BCE_mean=float(g.test_BCE.mean()) if g.reached.all() else None))
 pd.DataFrame(summary).to_csv(ROOT/'SIX_METHOD_QUALITY_COST.csv',index=False)
 # Identify trajectories: M0-M3 use the same base weights; COLD and REUSE also identical by protocol.
 equality=[]
 for seed in SEEDS:
  for ep in json.loads((ROOT/'FREEZE.json').read_text())['training']['checkpoints']:
   paths=[ROOT/'runs'/c/str(seed)/m/f'checkpoint_{ep}/predictions.npz' for c in ['COLD','REUSE'] for m in ['M0','M1','M2','M3']];raw=[np.load(p)['raw'] for p in paths if p.exists()];equality.append(dict(seed=seed,epoch=ep,compared=len(raw),raw_exact_equal=all(np.array_equal(raw[0],z) for z in raw)))
 assert all(r['raw_exact_equal'] for r in equality);dump(ROOT/'BASE_TRAJECTORY_CHECK.json',equality)
 graph_checks=[]
 for m in ['M4','M5']:
  for seed in SEEDS:
   for ep in json.loads((ROOT/'FREEZE.json').read_text())['training']['checkpoints']:
    ps=[ROOT/'runs'/c/str(seed)/m/f'checkpoint_{ep}/predictions.npz' for c in ['COLD','REUSE']]
    if all(p.exists() for p in ps):
     a,b=[np.load(p)['raw'] for p in ps];graph_checks.append(dict(method=m,seed=seed,epoch=ep,raw_exact_equal=bool(np.array_equal(a,b)),max_probability_difference=float(np.max(abs(expit(a)-expit(b))))))
 dump(ROOT/'GRAPH_CONDITION_CHECK.json',graph_checks)
 # Select replay methods on V_select only.
 r=pd.read_csv(ROOT/'REPLAY_CURVES.csv');v=r[r.split=='V_select'].sort_values(['AP','epoch'],ascending=[False,True]).groupby(['dataset','seed','method'],sort=False).head(1);s=r[r.split=='test'].merge(v[['dataset','seed','method','epoch']],on=['dataset','seed','method','epoch']);s.to_csv(ROOT/'REPLAY_SELECTED_TEST.csv',index=False)
 service=[json.loads(p.read_text()) for p in (ROOT/'service').glob('measure_*.json')]
 if service:
  flat=[]
  for x in service:flat.append({k:v for k,v in x.items() if not isinstance(v,(list,dict))}|{f'{stage}_{k}':v for stage in ['initial_memory','loaded_memory','query_memory'] for k,v in x[stage].items()})
  pd.DataFrame(flat).to_csv(ROOT/'SERVICE_RESULTS.csv',index=False)
 print('SUMMARIZED',flush=True)
if __name__=='__main__':main()
