import os
for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'): os.environ[k]='1'
from pathlib import Path
import hashlib,json,time
import numpy as np
from scipy.special import expit,logit
from scipy.optimize import minimize
from sklearn.metrics import average_precision_score
ROOT=Path(__file__).resolve().parents[1]
G=Path('/home/baibai/experiment/edbt_dual_iteration_20260924/graph_baseline_comparison_execution')
STAGE=G.parent/'two_stage_edbt_evidence/stage1'
OLD=Path('/home/baibai/experiment-final-validation/dual_token_final_20261002')
SPLITS={'GDSC':G/'gdsc_higsyn_20260928/SPLIT.npz','NCI':G/'nci_almanac/run/SPLIT.npz','ONEIL':G/'oneil_20260928/SPLIT.npz'}
SEEDS=(20260928,20260929,20260930)
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,x): Path(p).write_text(json.dumps(x,indent=2,ensure_ascii=False,allow_nan=False)+'\n')
def data(ds):
 with np.load(SPLITS[ds]) as f: rows=f['rows'];tr=f['train_i'];va=f['val_i'];te=f['test_i']
 # Deterministic identity ordering, independent of all labels; 40/30/30 exact counts.
 keys=['|'.join(map(str,r.astype(int))) for r in rows[:,:3]]
 va=np.array(sorted(va,key=lambda i:hashlib.sha256(('validation-v1|'+keys[i]).encode()).hexdigest()))
 a=int(len(va)*.4);b=int(len(va)*.7)
 return rows,tr,va[:a],va[a:b],va[b:],te

def calibrate(z,y):
 def fn(w):
  v=w[0]*z+w[1];e=expit(v)-y;d=w-np.array([1.,0.])
  return float(np.mean(np.logaddexp(0,v)-y*v)+.5*(d@d)/len(y)),np.array([e@z,e.sum()])/len(y)+d/len(y)
 o=minimize(fn,[1.,0.],jac=True,method='L-BFGS-B',bounds=[(1e-6,None),(None,None)],options={'maxiter':1000,'ftol':1e-14,'gtol':1e-9})
 assert np.isfinite(o.x).all()
 return o.x

def continuous(pid,y,base,P):
 n=np.bincount(pid,minlength=P);lo=-n.astype(float);hi=n.astype(float)
 for _ in range(80):
  m=(lo+hi)/2;g=np.bincount(pid,weights=expit(base+m[pid])-y,minlength=P)+m
  lo=np.where(g<0,m,lo);hi=np.where(g>=0,m,hi)
 return (lo+hi)/2,n

def quantize(v,n,pid,y,base,B):
 K=2**B;values=v[n>0];edges=np.quantile(values,np.linspace(0,1,K+1));bins=np.searchsorted(edges[1:-1],values,side='right');den=np.bincount(bins,minlength=K)
 centers=np.divide(np.bincount(bins,weights=values,minlength=K),den,out=np.zeros(K),where=den>0)
 costs=np.empty((len(n),K))
 for j,d in enumerate(centers):costs[:,j]=np.bincount(pid,weights=np.logaddexp(0,base+d)-y*(base+d),minlength=len(n))+.5*d*d
 codes=costs.argmin(1).astype(np.int16);codes[n==0]=-1
 return np.where(n>0,centers[codes.clip(0)],0.),codes,centers

def rawlog(p): return logit(np.clip(np.asarray(p,dtype=float),1e-7,1-1e-7))
def build(raw,rows,tr,vb):
 t=time.perf_counter();pairs,pid=np.unique(rows[:,:2].astype(int),axis=0,return_inverse=True);theta=calibrate(raw[vb],rows[vb,4]);base=theta[0]*raw+theta[1];cal_seconds=time.perf_counter()-t;t=time.perf_counter()
 v,n=continuous(pid[tr],rows[tr,4],base[tr],len(pairs));off,codes,centers=quantize(v,n,pid[tr],rows[tr,4],base[tr],4)
 return base+off[pid],dict(base=base,continuous=v,support=n,pairs=pairs,pid=pid,codes=codes,centers=centers,theta=theta,internal_calibration_seconds=cal_seconds,relation_seconds=time.perf_counter()-t)

def queries(rows):
 groups={'cell':{},'partner':{}}
 for i,(a,b,c) in enumerate(rows[:,:3].astype(int)):
  groups['cell'].setdefault(str(c),[]).append(i)
  for obj in set((a,b)):groups['partner'].setdefault(f'{c}:{obj}',[]).append(i)
 return {kind:{k:np.array(v) for k,v in qs.items()} for kind,qs in groups.items()}
def metrics(z,y,rows=None):
 p=expit(z);pos=y.sum();result={'AP':float(average_precision_score(y,z)) if pos else None,'BCE':float(np.mean(np.logaddexp(0,z)-y*z)),'error05':float(np.mean((p>=.5)!=y)),'recall05':float(np.sum((p>=.5)*y)/pos) if pos else None,'n':len(y)}
 if rows is not None:
  for kind,qs in queries(rows).items():
   for label in ('3','10pct'):
    ps=[];rs=[]
    for ix in qs.values():
     k=min(3,len(ix)) if label=='3' else max(1,int(np.ceil(.1*len(ix))))
     rank=ix[np.argsort(-z[ix],kind='stable')[:k]];hit=y[rank].sum();ps.append(hit/k)
     if y[ix].sum():rs.append(hit/y[ix].sum())
    result[f'{kind}_P{label}']=float(np.mean(ps)) if ps else None
    result[f'{kind}_R{label}']=float(np.mean(rs)) if rs else None
 return result
