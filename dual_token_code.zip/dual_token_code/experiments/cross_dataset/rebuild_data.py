"""Reconstruct sealed canonical populations from author release CSVs, never train."""
from core import *
import pandas as pd
from sklearn.model_selection import train_test_split
from collections import defaultdict
import argparse

def reconstruct(ds):
 if ds=='GDSC':
  root=G/'official_repos/HIGSyn/Data/GDSC2';d=pd.read_csv(root/'GDSC2_cid_unique.csv').drop_duplicates();c=pd.read_csv(root/'GDSC2_cellline(z_score).csv',index_col=0);dm={v:i for i,v in enumerate(d.DrugName)};cm={v:i+len(d) for i,v in enumerate(c.index)}
  f=pd.concat([pd.read_csv(root/f'GDSC2_cv5_{s}_fold_0.csv') for s in ('train','valid','test')]);groups=defaultdict(list)
  for row in f.itertuples(index=False,name=None):
   u,v,ct=row[:3];groups[(min(dm[u],dm[v]),max(dm[u],dm[v]),cm[ct])].append(int(row[f.columns.get_loc('label')]))
  assert all(len(set(v))==1 for v in groups.values())
  rows=np.array([[*k,v[0],v[0]] for k,v in sorted(groups.items())],dtype=float);ids=list(d.CIDs);cells=list(c.index);prefix='GDSC-v1'
 else:
  root=G/'official_repos/HERMES/data'/('ALMANAC-COSMIC' if ds=='NCI' else 'ONEIL-COSMIC');d=pd.read_csv(root/'drug_smiles.csv',index_col=0);c=pd.read_csv(root/'cell line_gene_expression.csv',index_col=0);f=pd.read_csv(root/'drug_synergy.csv');dm={int(v):i for i,v in enumerate(d.pubchemid)};cm={v:i+len(d) for i,v in enumerate(c.index)};groups=defaultdict(list)
  for u,v,ct,y in f.itertuples(index=False,name=None):
   if u in dm and v in dm and ct in cm:groups[(min(dm[u],dm[v]),max(dm[u],dm[v]),cm[ct])].append(float(y))
  rows=np.array([[*k,np.mean(v),int(np.mean(v)>=30)] for k,v in sorted(groups.items())],dtype=float);ids=list(d.pubchemid);cells=list(c.index);prefix='ONEIL-v1'
 if ds=='NCI':
  tr,rem=train_test_split(np.arange(len(rows)),test_size=.3,random_state=20260926,stratify=rows[:,4]);va,te=train_test_split(rem,test_size=.5,random_state=20260927,stratify=rows[rem,4])
 else:
  hashes=[]
  for u,v,ct in rows[:,:3].astype(int):
   a,b=sorted((int(ids[u]),int(ids[v])));ctx=cells[ct-len(d)];hashes.append(int.from_bytes(hashlib.sha256(f'{prefix}|{a}|{b}|{ctx}'.encode()).digest()[:8],'big')/2**64)
  h=np.array(hashes);tr=np.flatnonzero(h<.7);va=np.flatnonzero((h>=.7)&(h<.85));te=np.flatnonzero(h>=.85)
 return dict(rows=rows,train_i=tr,val_i=va,test_i=te)
if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,required=True);args=parser.parse_args();args.output.mkdir(parents=True,exist_ok=False);report={}
 for ds in SPLITS:
  arrays=reconstruct(ds)
  with np.load(SPLITS[ds]) as original:
   for k,v in arrays.items():np.testing.assert_array_equal(v,original[k])
  np.savez_compressed(args.output/f'{ds}_SPLIT.npz',**arrays);report[ds]=dict(rows=len(arrays['rows']),all_arrays_exact=True,source_sha256=sha(SPLITS[ds]))
 dump(args.output/'REBUILD_CHECK.json',report)
