import os
for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[k]='1'
import sys,json,time,random,resource,hashlib,importlib.util
from pathlib import Path
import numpy as np,torch
from sklearn.metrics import average_precision_score
from scipy.special import expit,logit
from core import *
ds=sys.argv[1];method=sys.argv[2];seed=int(sys.argv[3]);R=ROOT;N=G/'nci_almanac';O=Path(os.environ.get('SUPPLEMENT_OUTPUT',str(R/'runs')))/ds/str(seed)/method
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(n,v):
 with (O/n).open('x') as f:json.dump(v,f,indent=2,allow_nan=False)
def mod(n,p):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
def state(m):return {k:v.detach().cpu().clone() for k,v in m.state_dict().items()}
frozen_files=json.loads((R/'FREEZE.json').read_text())['files'];frozen_files.update(json.loads((R/'TIMING_REPAIR.json').read_text())['repaired_files'])
for p,h in frozen_files.items():assert sha(p)==h,p
wall_started=time.perf_counter()
os.sched_setaffinity(0,{json.loads((R/'FREEZE.json').read_text())['service']['affinity']})
O.mkdir(parents=True,exist_ok=False)
random.seed(seed);np.random.seed(seed);torch.manual_seed(seed);torch.cuda.manual_seed_all(seed)
torch.backends.cudnn.deterministic=True;torch.backends.cudnn.benchmark=False;torch.set_num_threads(1)
dev=torch.device('cuda:0');assert torch.cuda.is_available()
rows,tr,vb,vs,vc,te=data(ds);va=vs
x=torch.tensor(rows[:,:3],dtype=torch.long,device=dev);yt=torch.tensor(rows[tr,4],dtype=torch.float32,device=dev)
prep=time.perf_counter()
if ds=='GDSC':
 A=G/'official_repos'/('MoCo-MultiSynergy' if method=='MOCO' else 'HERMES');sys.path.insert(0,str(A/'Model'))
 work=O/'working';work.mkdir();os.chdir(work)
 import pandas as pd,deepchem as dc
 from rdkit import Chem
 from drug_util import GraphDataset,collate,drug_feature_extract
 from utils import get_MACCS
 if method=='MOCO':
  from model import Initializer,Refiner,Consolidator,MoCo_MultiSynergy
 else:
  from HERMES.model import Initializer,Refiner,Consolidator,HERMERS
 I=STAGE/'GDSC_INPUTS';d=pd.read_csv(I/'drugs.csv',index_col=0);gene=pd.read_csv(I/'cells.csv',index_col=0);cell_np=gene.to_numpy(dtype=np.float32);disease_np=np.load(I/'disease.npy');interactions=np.load(I/'interactions.npy')
 features=pd.DataFrame();maccs=[];ids=[];featurizer=dc.feat.ConvMolFeaturizer()
 for row in d.itertuples():
  mol=featurizer.featurize(Chem.MolFromSmiles(row.smiles))[0];features[str(int(row.CIDs))]=[mol.get_atom_features(),mol.get_adjacency_list()];maccs.append(get_MACCS(row.smiles));ids.append(int(row.CIDs))
 if method=='MOCO':
  from process_data import get_drug_feature_matrix
  drug=drug_feature_extract(features,ids);dataset=GraphDataset(graphs_dict=get_drug_feature_matrix(drug),drug_ids=ids)
 else:
  drug=drug_feature_extract(features);dataset=GraphDataset(graphs_dict=drug)
 assert len(drug)==35 and len(cell_np)==447 and len(rows)==30812
else:
 if method=='MOCO':
  A=G/'official_repos/MoCo-MultiSynergy';sys.path.insert(0,str(A/'Model'))
  work=O/'layout/Model/runner';work.mkdir(parents=True);(O/'layout/data').symlink_to(A/'data',target_is_directory=True);os.chdir(work)
  from process_data import getData,get_drug_feature_matrix
  from drug_util import GraphDataset,collate
  from model import Initializer,Refiner,Consolidator,MoCo_MultiSynergy
  drug,maccs,cell_np,gene,synergy,disease_np,interactions,_,ids=getData('ONEIL' if ds=='ONEIL' else 'ALMANAC',True)
  dataset=GraphDataset(graphs_dict=get_drug_feature_matrix(drug),drug_ids=ids)
 else:
  A=G/'official_repos/HERMES';sys.path.insert(0,str(A/'Model'));os.chdir(A/'Model')
  from process_data import getData
  drug,maccs,cell_np,gene,synergy,disease_np,interactions=getData('ONEIL' if ds=='ONEIL' else 'ALMANAC',True)
  if method=='HERMES':
   from drug_util import GraphDataset,collate
   from HERMES.model import Initializer,Refiner,Consolidator,HERMERS
   dataset=GraphDataset(graphs_dict=drug)
 from collections import defaultdict
 g=defaultdict(list)
 for a,b,c,y in synergy:g[(min(int(a),int(b)),max(int(a),int(b)),int(c))].append(float(y))
 reconstructed=np.array([[*k,np.mean(v),int(np.mean(v)>=30)] for k,v in sorted(g.items())]);assert np.array_equal(rows,reconstructed)
if method=='Q4':
 om=mod('fixed_object',N/'quality_gap_execution_20260928/train.py');repair=mod('fixed_repair',N/'quality_gap_execution_20260928/repair.py')
 cf=(cell_np-cell_np.mean(0,keepdims=True))/np.maximum(cell_np.std(0,keepdims=True),1e-6)
 model=om.ObjectModel(np.asarray(maccs,dtype=np.float32),cf).to(dev)
 opt=torch.optim.AdamW(model.parameters(),lr=1e-3,weight_decay=1e-4)
else:
 from similarity import get_Cosin_Similarity,get_pvalue_matrix
 from utils import TruncatedExponentialLR
 if not hasattr(np,'mat'):np.mat=np.asmatrix
 graph=next(iter(torch.utils.data.DataLoader(dataset,collate_fn=collate,batch_size=len(drug),shuffle=False))).to(dev)
 cell=torch.tensor(cell_np,dtype=torch.float32,device=dev);disease=torch.tensor(disease_np,dtype=torch.float32,device=dev)
 pos=x[tr][yt==1].cpu().numpy();ints=np.array(interactions,dtype=np.int64)
 hs=torch.tensor(np.stack((pos.ravel(),np.repeat(np.arange(len(pos)),3))),dtype=torch.long,device=dev)
 hi=torch.tensor(np.stack((ints.ravel(),np.repeat(np.arange(len(ints)),2))),dtype=torch.long,device=dev)
 sims=[torch.tensor(v,dtype=torch.float32,device=dev) for v in [get_Cosin_Similarity(maccs),get_pvalue_matrix(np.array(gene,dtype=np.float32)),get_pvalue_matrix(disease_np)]]
prep_seconds=time.perf_counter()-wall_started
dump('ADMISSION.json',dict(population_exact=True,preparation_seconds=prep_seconds,train=len(tr),validation=len(va)))
torch.cuda.reset_peak_memory_stats();torch.cuda.synchronize();started=time.perf_counter()
if method=='MOCO':
 pre=Initializer(75,cell.shape[1],256,use_disease=True,use_moco=True).to(dev);op=torch.optim.Adam(pre.parameters(),lr=1e-4,weight_decay=1e-5)
 for epoch in range(100):
  pre.train();op.zero_grad();*_,loss=pre(graph.x,graph.edge_index,graph.batch,cell,disease);assert torch.isfinite(loss);loss.backward();op.step()
 ps=state(pre);torch.save(ps,O/'PRETRAIN.pt');init=Initializer(75,cell.shape[1],256,use_disease=True,use_moco=True);init.load_state_dict(ps,strict=False)
 model=MoCo_MultiSynergy(init,Refiner(256,256),Consolidator(256),use_disease=True,use_moco=True).to(dev)
 after=state(model.initializer);dump('AUTHOR_CONSTRUCTOR_BEHAVIOR.json',dict(changed=[k for k,v in ps.items() if not torch.equal(v,after[k])],preserved=True));del pre,op,ps,after
 model.initializer.drug_moco.T=.1;model.initializer.cline_moco.T=.1
elif method=='HERMES':model=HERMERS(Initializer(75,cell.shape[1],256),Refiner(256,256),Consolidator(256),use_disease=True).to(dev)
if method!='Q4':
 model.initialize(hs,hi.clone(),num_synergy=len(pos));opt=torch.optim.Adam(model.parameters(),lr=1e-4,weight_decay=1e-2);sched=TruncatedExponentialLR(opt,gamma=.9997,min_lr=2e-6)
def forward(ix):return model(graph.x,graph.edge_index,graph.batch,cell,x[ix,0],x[ix,1],x[ix,2],disease)

from core import calibrate,build,rawlog,metrics
checkpoint_nodes=json.loads((R/'FREEZE.json').read_text())['training']['checkpoints']
if os.environ.get('SUPPLEMENT_SMOKE')=='1':checkpoint_nodes=[1,2]
torch.cuda.synchronize();pretrain_seconds=time.perf_counter()-started
phase=dict(preparation=prep_seconds,pretraining=pretrain_seconds,training=0.,prediction=0.,internal_calibration_and_relation=0.,internal_calibration=0.,relation=0.,final_calibration=0.,validation=0.,save=0.)
best=-1.;bce=torch.nn.BCELoss();history=[]
for epoch in range(1,max(checkpoint_nodes)+1):
 torch.cuda.synchronize();t=time.perf_counter()
 model.train();opt.zero_grad()
 if method=='Q4':loss=torch.nn.functional.binary_cross_entropy_with_logits(model(x[tr]),yt)
 else:
  outputs=forward(tr);p,rec=outputs[:2];loss=bce(p,yt)+.01*sum(bce(a,b) for a,b in zip(rec,sims))
  if method=='MOCO':loss=loss+.02*outputs[2]
 assert torch.isfinite(loss);loss.backward();opt.step()
 if method!='Q4':sched.step()
 torch.cuda.synchronize();phase['training']+=time.perf_counter()-t
 if epoch not in checkpoint_nodes:
  if time.perf_counter()-wall_started>900:break
  continue
 model.eval();t=time.perf_counter()
 with torch.no_grad():prob=torch.sigmoid(model(x)) if method=='Q4' else forward(np.arange(len(rows)))[0]
 raw=rawlog(prob.cpu().numpy());torch.cuda.synchronize();phase['prediction']+=time.perf_counter()-t
 t=time.perf_counter()
 if method=='Q4':
  z,relation=build(raw,rows,tr,vb);phase['internal_calibration']+=float(relation['internal_calibration_seconds']);phase['relation']+=float(relation['relation_seconds'])
 else:z=raw
 phase['internal_calibration_and_relation']+=time.perf_counter()-t
 t=time.perf_counter();theta=calibrate(z[vc],rows[vc,4]);final=theta[0]*z+theta[1];phase['final_calibration']+=time.perf_counter()-t
 t=time.perf_counter();met=metrics(final[vs],rows[vs,4],rows[vs]);pre_ap=average_precision_score(rows[vs,4],z[vs]);assert abs(met['AP']-pre_ap)<1e-12
 phase['validation']+=time.perf_counter()-t
 t=time.perf_counter();cp=O/f'checkpoint_{epoch}';cp.mkdir()
 torch.save(dict(state_dict=state(model),epoch=epoch),cp/'model.pt')
 np.savez(cp/'predictions.npz',raw=raw,pre=z,final=final,calibration=theta)
 if method=='Q4':np.savez(cp/'relation.npz',**relation)
 if met['AP']>best:best=met['AP'];best_epoch=epoch
 torch.cuda.synchronize();phase['save']+=time.perf_counter()-t
 rec=dict(epoch=epoch,processed_samples=epoch*len(tr),supervised_updates=epoch,pretrain_updates=100 if method=='MOCO' else 0,augmentation='author model internal behavior retained; no extra ordering augmentation',metrics=met,phase=dict(phase),complete_seconds=time.perf_counter()-wall_started)
 history.append(rec)
 with (O/'TRAJECTORY.jsonl').open('a') as f:f.write(json.dumps(rec)+'\n')
 print(ds,method,seed,epoch,rec['complete_seconds'],flush=True)
 if rec['complete_seconds']>900:break
assert history
selected=O/f'checkpoint_{best_epoch}'
dump('SELECTED.json',dict(epoch=best_epoch,validation_AP=best,selection='complete predictor V_select AP, earliest tie',prediction_sha256=sha(selected/'predictions.npz'),weight_sha256=sha(selected/'model.pt'),test_metrics_not_computed=True))
dump('TRAINING.json',dict(dataset=ds,method=method,seed=seed,phase=phase,wall_seconds=time.perf_counter()-wall_started,updates=epoch,pretrain_updates=100 if method=='MOCO' else 0,peak_cuda_allocated=torch.cuda.max_memory_allocated(),peak_cuda_reserved=torch.cuda.max_memory_reserved(),process_peak_RSS=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024,checkpoints=len(history)))
