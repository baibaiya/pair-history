"""Post-hoc implementation repair: apply the originally frozen canonical tie order."""
from core import metrics as original_metrics
import numpy as np

def canonical_metrics(z,y,rows=None):
 if rows is not None:
  order=np.lexsort((rows[:,2],rows[:,1],rows[:,0]))
  z,y,rows=z[order],y[order],rows[order]
 return original_metrics(z,y,rows)
