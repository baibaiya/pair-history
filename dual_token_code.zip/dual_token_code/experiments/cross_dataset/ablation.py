from core import *
import torch,importlib.util
from scipy.stats import kendalltau

def load_object(ds,seed):
 if ds=='GDSC':p=G/'gdsc_higsyn_20260928'/str(seed)/'Q4/BEST.pt'
 elif ds=='ONEIL':p=G/'oneil_20260928'/str(seed)/'Q4/BEST.pt'
 elif seed==20260926:p=G/'nci_almanac/quality_gap_execution_20260928/BEST.pt'
 else:p=OLD/'nci_runs'/str(seed)/'NEW_Q4/BEST.pt'
 s=torch.load(p,weights_only=True,map_location='cpu')['state_dict']
 spec=importlib.util.spec_from_file_location('object_definition',G/'nci_almanac/quality_gap_execution_20260928/train.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
 model=mod.ObjectModel(s['drug'].numpy(),s['cell'].numpy());model.load_state_dict(s);model.eval();torch.set_num_threads(1)
 rows,*_=data(ds)
 with torch.no_grad():pred=torch.cat([torch.sigmoid(model(torch.tensor(x[:,:3],dtype=torch.long))) for x in np.array_split(rows,32)]).numpy()
 return rawlog(pred),s,p

def pack(codes,B):
 values=codes.clip(0).astype(np.uint16);bits=((values[:,None]>>np.arange(B))&1).astype(np.uint8).ravel();return np.packbits(bits,bitorder='little')
def run():
 out=ROOT/'ablations';out.mkdir(exist_ok=False);allrows=[];details={}
 for ds in SPLITS:
  rows,tr,vb,vs,vc,te=data(ds);y=rows[:,4];seeds=SEEDS if ds!='NCI' else (20260926,20260929,20260930)
  for seed in seeds:
   raw,weights,weightpath=load_object(ds,seed);q,st=build(raw,rows,tr,vb);base=st['base'];n=st['support'];pid=st['pid'];P=len(n);v=st['continuous']
   sums=np.bincount(pid[tr],weights=y[tr],minlength=P);globalp=y[tr].mean()
   taus=[1,4,16,64,256];prior={t:(sums+t*globalp)/(n+t) for t in taus}
   tau=min(taus,key=lambda t:metrics(rawlog(prior[t][pid[vb]]),y[vb])['BCE']);pr=rawlog(prior[tau][pid]);X=np.column_stack((np.ones(len(rows)),base,pr))
   def fun(b):
    z=X[vb]@b;e=expit(z)-y[vb]
    return float(np.sum(np.logaddexp(0,z)-y[vb]*z)+.5*b@b),X[vb].T@e+b
   fit=minimize(fun,[0,1,0],jac=True,method='L-BFGS-B',options={'maxiter':1000,'ftol':1e-13,'gtol':1e-7});assert fit.success or np.linalg.norm(fit.jac)<1e-4
   preds={'A0_GLOBAL':np.full(len(rows),logit(globalp)),'A1_PRIOR':pr,'A2_BASE':base,'A3_COMBINATION':X@fit.x,'A4_FLOAT':base+v[pid]}
   dest=out/ds/str(seed);dest.mkdir(parents=True)
   torch.save(weights,dest/'object_state.pt');rows[:,:3].astype(np.int32).tofile(dest/'coverage.bin');st['pairs'].astype(np.int32).tofile(dest/'pair_addresses.bin');np.packbits(n>0).tofile(dest/'supported.bin');st['theta'].astype(np.float64).tofile(dest/'calibration.bin')
   common=sum(p.stat().st_size for p in dest.iterdir() if p.is_file());statebytes={};floatz=preds['A4_FLOAT']
   v.astype(np.float64).tofile(dest/'float64_offsets_diagnostic.bin')
   for B in (1,2,3,4,8):
    off,codes,centers=quantize(v,n,pid[tr],y[tr],base[tr],B);preds[f'A5_Q{B}']=base+off[pid]
    packed=pack(codes,B);packed.tofile(dest/f'q{B}.bin');centers.tofile(dest/f'centers{B}.bin')
    unpack=np.unpackbits(packed,bitorder='little')[:len(codes)*B].reshape(-1,B)@(2**np.arange(B));np.testing.assert_array_equal(unpack,codes.clip(0))
    z=preds[f'A5_Q{B}'];statebytes[B]=dict(logical_bits=B,packed_code_bytes=packed.nbytes,centers_bytes=centers.nbytes,relation_state_bytes=packed.nbytes+centers.nbytes+int(np.ceil(P/8))+P*8,common_bytes=common,full_persistent_bytes=common+packed.nbytes+centers.nbytes,occupied_codes=len(np.unique(codes[codes>=0])),empty_initial_centers=int(np.sum(np.bincount(np.searchsorted(np.quantile(v[n>0],np.linspace(0,1,2**B+1))[1:-1],v[n>0],side='right'),minlength=2**B)==0)),probability_MAE=float(np.mean(abs(expit(z[te])-expit(floatz[te])))),probability_max_error=float(np.max(abs(expit(z[te])-expit(floatz[te])))),offset_MAE=float(np.mean(abs(off-v))),kendall_tau=float(kendalltau(z[te],floatz[te]).statistic))
   bins=np.digitize(n,[1,5,16]);codes=st['codes'].copy();rng=np.random.default_rng(20260928)
   for b in np.unique(bins):ix=np.flatnonzero(bins==b);codes[ix]=codes[rng.permutation(ix)]
   off=np.where(codes>=0,st['centers'][codes.clip(0)],0.);preds['A6_PERMUTED']=base+off[pid]
   np.savez(dest/'predictions.npz',**preds);np.savez(dest/'support.npz',support=n,positive=sums,pid=pid,residual=np.divide(np.bincount(pid[tr],weights=y[tr]-expit(base[tr]),minlength=P),n,out=np.zeros(P),where=n>0))
   detail=dict(weight=str(weightpath),weight_sha256=sha(weightpath),tau=tau,beta=fit.x.tolist(),storage=statebytes,float_full_bytes=common+P*8,float_precision='FP64 arithmetic and storage; FP32 logical alternative '+str(common+P*4),sample_population='historical fixed weights, rebuilt V_build calibration; development only')
   dump(dest/'DETAILS.json',detail);details[f'{ds}/{seed}']=detail
   for name,z in preds.items():allrows.append(dict(experiment='A_fixed',dataset=ds,seed=seed,method=name,**metrics(z[te],y[te],rows[te])))
 dump(out/'METRICS.json',allrows);dump(out/'DETAILS.json',details)
 print('A_COMPLETE',flush=True)
if __name__=='__main__':run()
