"""Independent 50,000 paired cluster draws, exact original RNG prefix; no model fitting."""
import os
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='1'
from pathlib import Path
import ctypes,subprocess,json,hashlib
import numpy as np
import pandas as pd
from scipy.stats import binom
R=Path(__file__).resolve().parents[1];D=R/'statistics';D.mkdir(exist_ok=True)
F=json.loads((R/'FREEZE.json').read_text());B=F['statistics']['replicates'];assert B==50000
src=R/'scripts/bootstrap_kernel.cpp';lib=D/'bootstrap_kernel.so'
subprocess.run(['g++','-O3','-std=c++17','-shared','-fPIC',str(src),'-o',str(lib)],check=True)
fn=ctypes.CDLL(str(lib)).evaluate;ptr=np.ctypeslib.ndpointer
fn.argtypes=[ctypes.c_int,ctypes.c_int,ctypes.c_int,ptr(dtype=np.int16,flags='C_CONTIGUOUS'),ptr(dtype=np.int64,flags='C_CONTIGUOUS'),ptr(dtype=np.float64,flags='C_CONTIGUOUS'),ptr(dtype=np.float64,flags='C_CONTIGUOUS'),ptr(dtype=np.int64,flags='C_CONTIGUOUS'),ptr(dtype=np.float64,flags='C_CONTIGUOUS')]
rows=np.load(R/'inputs/test_rows.npz')['rows'];y=np.ascontiguousarray(rows[:,4],dtype=float);pred=np.load(R/'inputs/test_predictions.npz');comp=pd.read_csv(R/'COMPARISONS.csv')
def ordered_ap(z):
 order=np.argsort(-z,kind='stable');zz=z[order];yy=y[order];ends=np.r_[np.flatnonzero(zz[1:]!=zz[:-1]),len(z)-1]
 def ap(w):
  w=w[order];tp=np.cumsum(w*yy)[ends];total=np.cumsum(w)[ends]
  return np.sum(np.diff(np.r_[0,tp])*np.divide(tp,total,out=np.zeros_like(tp),where=total>0))/tp[-1]
 return ap
points={k:np.array([ordered_ap(pred[k])(np.ones(len(y))),np.mean(np.logaddexp(0,pred[k])-y*pred[k])]) for k in pred.files}
outputs=[];prefixes=[];checks=[]
for unit in ['pair','cell']:
 groups=np.ascontiguousarray(np.unique(rows[:,:2] if unit=='pair' else rows[:,2:3],axis=0,return_inverse=True)[1],dtype=np.int64);P=int(groups.max()+1);rng=np.random.default_rng(20261002)
 weights=np.array([np.bincount(rng.integers(P,size=P),minlength=P) for _ in range(B)],dtype=np.int16)
 draws={};equivalent={};sha=hashlib.sha256(weights.tobytes()).hexdigest()
 for key in pred.files:
  z=np.ascontiguousarray(pred[key],dtype=float);order=np.ascontiguousarray(np.argsort(-z,kind='stable'),dtype=np.int64);out=np.empty((B,2),dtype=float)
  digest=hashlib.sha256(z.tobytes()).hexdigest()
  if digest in equivalent:out=equivalent[digest]
  else:fn(B,len(y),P,weights,groups,y,z,order,out);equivalent[digest]=out
  # Independent Python implementation at predeclared draw indices verifies ties and multiplicity.
  for b in [0,1,1999,9999,49999]:
   w=weights[b][groups].astype(float);expected=[ordered_ap(z)(w),np.sum(w*(np.logaddexp(0,z)-y*z))/w.sum()]
   np.testing.assert_allclose(out[b],expected,atol=2e-13,rtol=0)
  draws[key]=out
 np.savez_compressed(D/f'{unit}_draws.npz',**draws)
 checks.append(dict(unit=unit,clusters=P,draws=B,weights_sha256=sha,independent_kernel_check=True))
 for r in comp[comp.unit==unit].to_dict('records'):
  j=0 if r['metric']=='AP' else 1;c=draws[r['candidate_key']][:,j];ref=draws[r['reference_key']][:,j]
  loss=1-c/ref if j==0 else c/ref-1;point=1-points[r['candidate_key']][j]/points[r['reference_key']][j] if j==0 else points[r['candidate_key']][j]/points[r['reference_key']][j]-1
  oldlo,oldhi=np.quantile(loss[:2000],[.025,.975])
  if pd.notna(r.get('old_low')):
   np.testing.assert_allclose([oldlo,oldhi],[r['old_low'],r['old_high']],atol=2e-11,rtol=0)
   old_source='archived_and_reproduced'
  else:old_source='same_original_2000_draw_protocol_recomputed' if r['section'].startswith('A') else 'new_predictor_2000_prefix_diagnostic'
  for n in [2000,10000,25000,50000]:
   lo,hi=np.quantile(loss[:n],[.025,.975]);ordered=np.sort(loss[:n]);li=max(0,int(binom.ppf(.025,n,.975))-1);ui=min(n-1,int(binom.ppf(.975,n,.975)))
   mc_lo,mc_hi=ordered[li],ordered[ui]
   p=dict(**r,replicates=n,new_low=lo,new_high=hi,upper_mc_low=mc_lo,upper_mc_high=mc_hi,mc_lower_order_index=li,mc_upper_order_index=ui)
   prefixes.append(p)
   if n==50000:
    status=lambda lo,hi:'confirmed' if hi<=.05 else ('confirmed_degradation' if lo>.05 else 'unconfirmed')
    outputs.append(dict(**p,relative_loss=point,point_pass=point<=.05,old_low_2000=oldlo,old_high_2000=oldhi,old_source=old_source,old_confirmation=oldhi<=.05,new_confirmation=hi<=.05,status_changed=(oldhi<=.05)!=(hi<=.05),new_status=status(lo,hi),mc_boundary_sensitive=mc_lo<=.05<=mc_hi))
 print('Completed',unit,'bootstrap',len(draws),'predictors',flush=True)
pd.DataFrame(outputs).to_csv(R/'INTERVAL_STABILITY.csv',index=False);pd.DataFrame(prefixes).to_csv(R/'ENDPOINT_PREFIXES.csv',index=False)
(R/'BOOTSTRAP_CHECK.json').write_text(json.dumps(dict(checks=checks,all_archived_2000_endpoints_reproduced=True,kernel_vs_python_absolute_tolerance=2e-13),indent=2))
print('All intervals complete',len(outputs),flush=True)
