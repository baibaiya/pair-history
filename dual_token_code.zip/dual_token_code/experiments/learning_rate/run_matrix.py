from pathlib import Path
import os,json,subprocess,sys,time,fcntl,hashlib
R=Path(__file__).resolve().parents[1];S=R.parent/'dual_token_supplement_20261002'
lock=(R/'RUN.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
assert (R/'FREEZE.json').exists()
for seed in [20260928,20260929,20260930]:
 for tag,mult in [('third',1/3),('triple',3)]:
  for method in ['M3','M4','M2','M5']:
   dest=R/'runs'/tag/'REUSE'/str(seed)/method
   if (dest/'TRAINING.json').exists():continue
   assert not dest.exists(),f'Partial run retained: {dest}'
   gpu=subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip();assert not gpu,gpu
   name=f'{tag}_{seed}_{method}'
   (R/'logs'/f'{name}_resource.txt').write_text(subprocess.check_output(['ps','-eo','pid,etime,pcpu,args','--sort=-pcpu'],text=True))
   env=dict(os.environ,SUPPLEMENT_OUTPUT=str(R/'runs'/tag));env.pop('SUPPLEMENT_SMOKE',None)
   t=time.perf_counter()
   with (R/'logs'/f'{name}.log').open('x') as f:p=subprocess.run([sys.executable,str(R/'scripts/train.py'),method,str(seed),'REUSE',str(mult)],env=env,stdout=f,stderr=subprocess.STDOUT)
   (R/'logs'/f'{name}_process.json').write_text(json.dumps(dict(returncode=p.returncode,external_process_wall_seconds=time.perf_counter()-t)))
   assert p.returncode==0,name
   print('DONE',name,flush=True)
(R/'TRAINING_COMPLETE.json').write_text(json.dumps({'completed':True,'new_trajectories':24}))
