"""Validation selection is sealed before accessing any new test score."""
import os
for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='1'
from pathlib import Path
import json,hashlib
import numpy as np
import pandas as pd
from core import data,metrics,sha,dump,SPLITS
R=Path(__file__).resolve().parents[1];S=R.parent/'dual_token_supplement_20261002';P=R.parent/'paper/dual_token_edbt_v04_20261002'
F=json.loads((R/'FREEZE.json').read_text());refs=pd.read_csv(P/'audit/FROZEN_REFERENCES.csv'); rows,tr,vb,vs,vc,te=data('GDSC')
assert (R/'TRAINING_COMPLETE.json').exists()
with np.load(P/'audit/evaluation_rows.npz') as sealed:
 np.testing.assert_array_equal(rows[te],sealed['test_rows']);np.testing.assert_array_equal(rows[vs],sealed['validation_rows'])
curves=[];configs=[];choices=[]
for seed in F['seeds']:
 for method in F['methods']:
  for tag,mult in [('third',1/3),('original',1),('triple',3)]:
   run=(S/'runs' if tag=='original' else R/'runs'/tag)/'REUSE'/str(seed)/method
   train=json.loads((run/'TRAINING.json').read_text());hist=[json.loads(l) for l in (run/'TRAJECTORY.jsonl').read_text().splitlines()]
   processfile=S/'logs'/f'process_REUSE_{seed}_{method}.json' if tag=='original' else R/'logs'/f'{tag}_{seed}_{method}_process.json'
   external=json.loads(processfile.read_text())['external_process_wall_seconds']
   common=dict(seed=seed,method=method,method_name=F['methods'][method],tag=tag,multiplier=mult,lr=F['base_lr'][method]*mult,condition='REUSE',run=str(run),reused=tag=='original',full_search_component_seconds=external,full_process_seconds=train['process_seconds'],updates=train['updates'],timeout=train['updates']<3000)
   for h in hist:curves.append(dict(**common,epoch=h['epoch'],AP=h['metrics']['AP'],BCE=h['metrics']['BCE'],process_seconds=h['process_seconds'],complete_seconds=h['complete_seconds']))
   for ref in refs[refs.seed==seed].itertuples():
    ok=[h for h in hist if h['metrics']['AP']>=ref.target_AP and h['metrics']['BCE']<=ref.target_BCE]
    hit=ok[0] if ok else None;diag=max(hist,key=lambda h:h['metrics']['AP'])
    h=hit if hit else diag
    configs.append(dict(**common,reference=ref.reference,reached=hit is not None,role='first_hit' if hit else 'unattained_validation_best_diagnostic',epoch=h['epoch'],validation_AP=h['metrics']['AP'],validation_BCE=h['metrics']['BCE'],target_AP=ref.target_AP,target_BCE=ref.target_BCE,process_seconds=h['process_seconds'] if hit else None,complete_seconds=h['complete_seconds'] if hit else None,diagnostic_materialization_seconds=h['process_seconds'],phase=h['phase'],checkpoint=str(run/f"checkpoint_{h['epoch']}")))
for seed in F['seeds']:
 for method in F['methods']:
  for ref in ['HERMES','MOCO']:
   c=[r for r in configs if r['seed']==seed and r['method']==method and r['reference']==ref];ok=[r for r in c if r['reached']]
   choice=min(ok,key=lambda r:(r['process_seconds'],r['multiplier'],r['epoch'])) if ok else None
   choices.append(dict(seed=seed,method=method,reference=ref,selected_tag=choice['tag'] if choice else None,selected_epoch=choice['epoch'] if choice else None,search_cost_seconds=sum(r['full_search_component_seconds'] for r in c),new_search_cost_seconds=sum(r['full_search_component_seconds'] for r in c if not r['reused']),selection_uses_test=False))
pd.DataFrame(curves).to_csv(R/'VALIDATION_CURVES.csv',index=False)
seal=dict(rule=F['selection'],choices=choices,configs=configs,test_arrays_opened=False)
if (R/'VALIDATION_SELECTION.json').exists():assert json.loads((R/'VALIDATION_SELECTION.json').read_text())==seal
else:dump(R/'VALIDATION_SELECTION.json',seal)
# Verify stored validation log values from the saved scoring arrays after selection is sealed.
for c in curves:
 z=np.load(Path(c['run'])/f"checkpoint_{c['epoch']}"/'predictions.npz')['final']
 m=metrics(z[vs],rows[vs,4]);np.testing.assert_allclose([m['AP'],m['BCE']],[c['AP'],c['BCE']],atol=1e-12,rtol=0)
dump(R/'VALIDATION_RECOMPUTE_CHECK.json',dict(checkpoints=len(curves),all_AP_BCE_recomputed=True,selection_saved_before_test_metrics=True))
# Test arrays are first accessed only below this persisted selection boundary.
pred={};identities={};comparisons=[]
def register(cp):
 cp=Path(cp);key=hashlib.sha256(str(cp).encode()).hexdigest()[:20]
 if key not in pred:
  arrays=np.load(cp/'predictions.npz');z=arrays['final']; pred[key]=z[te] if len(z)==len(rows) else z
  identities[key]=dict(checkpoint=str(cp),epoch=int(cp.name.split('_')[-1]),files={f:sha(cp/f) for f in ['model.pt','predictions.npz','auxiliary.npz','relation.npz'] if (cp/f).exists()},input_manifest_sha256=F['input_manifest_sha256'],split_source=str(SPLITS['GDSC']),split_sha256=sha(SPLITS['GDSC']),partition_hashes={n:hashlib.sha256(a.astype(np.int64).tobytes()).hexdigest() for n,a in [('train',tr),('V_build',vb),('V_select',vs),('V_cal',vc),('test',te)]},prediction_array_hashes={n:hashlib.sha256(np.ascontiguousarray(arrays[n]).tobytes()).hexdigest() for n in arrays.files},actual_config=json.loads((cp.parent/'ACTUAL_CONFIG.json').read_text()) if (cp.parent/'ACTUAL_CONFIG.json').exists() else None)
 return key
refkeys={}
oldids=json.loads((P/'audit/PREDICTOR_IDENTITIES.json').read_text())
for r in refs.itertuples():
 cp=Path(oldids[r.key]['source']).parent;refkeys[(r.seed,r.reference)]=register(cp)
 assert sha(cp/'predictions.npz')==oldids[r.key]['prediction_file_sha256']
 assert sha(cp/'model.pt')==oldids[r.key]['weight_sha256']
 z=np.load(cp/'predictions.npz')['final'];v=metrics(z[vs],rows[vs,4]);t=metrics(z[te],rows[te,4]);np.testing.assert_allclose([v['AP'],v['BCE'],t['AP'],t['BCE'],.95*v['AP'],1.05*v['BCE']],[r.validation_AP,r.validation_BCE,r.test_AP,r.test_BCE,r.target_AP,r.target_BCE],atol=1e-12,rtol=0)
result=[];cost=[]
for c in configs:
 c=c.copy();phase=c.pop('phase');key=register(c['checkpoint']);rk=refkeys[c['seed'],c['reference']]
 met=metrics(pred[key],rows[te,4]);refmet=metrics(pred[rk],rows[te,4]);choice=next(x for x in choices if all(x[k]==c[k] for k in ['seed','method','reference']))
 c.update(candidate_key=key,reference_key=rk,test_AP=met['AP'],test_BCE=met['BCE'],test_AP_relative_loss=1-met['AP']/refmet['AP'],test_BCE_relative_loss=met['BCE']/refmet['BCE']-1,test_point_pass=met['AP']>=.95*refmet['AP'] and met['BCE']<=1.05*refmet['BCE'],validation_selected=c['tag']==choice['selected_tag'],search_cost_seconds=choice['search_cost_seconds'],new_search_cost_seconds=choice['new_search_cost_seconds'])
 result.append(c);cost.append(dict(**{k:c[k] for k in ['seed','method','tag','reference','role','epoch','reached','process_seconds','complete_seconds']},**phase,common_import_startup_seconds=c['diagnostic_materialization_seconds']-next(h['complete_seconds'] for h in curves if all(h[k]==c[k] for k in ['seed','method','tag','epoch'])),other_measured_overhead_seconds=next(h['complete_seconds'] for h in curves if all(h[k]==c[k] for k in ['seed','method','tag','epoch']))-sum(phase.values()),phase_scope='cumulative to diagnostic checkpoint when unreached'))
 if c['reached']:
  for unit in ['pair','cell']:
   for metric in ['AP','BCE']:comparisons.append(dict(section='B',**{k:c[k] for k in ['seed','method','tag','reference','role','epoch','candidate_key','reference_key','validation_selected']},condition='REUSE',unit=unit,metric=metric))
# A: complete main GDSC table, both original conditions and roles; no cherry-picking.
a=pd.read_csv(P/'evidence/QUALITY_INTERVALS.csv');a=a[(a.dataset=='GDSC')&a.metric.isin(['AP','BCE'])]
for r in a.to_dict('records'):
 comparisons.append(dict(section='A_main',**{k:r[k] for k in ['seed','method','condition','reference','role','epoch','unit','metric']},tag='original',candidate_key=register(r['candidate_key']),reference_key=register(r['reference_key']),old_low=r['loss_low'],old_high=r['loss_high'],old_status=r['status']))
# A: independent simple methods, both timing conditions, preserve nonattainments separately.
hits=pd.read_csv(P/'audit/EXPECTED_FIRST_HITS.csv');simple=hits[hits.method.isin(['M0','M1','M2','M3'])];simple[~simple.reached].to_csv(R/'A_NONATTAINMENTS.csv',index=False)
old=pd.read_csv(P/'evidence/supplement/DENSE_EARLY_ALL_INTERVALS.csv')
for h in simple[simple.reached].itertuples():
 ck=register(S/'runs'/h.condition/str(h.seed)/h.method/f'checkpoint_{int(h.epoch)}');rk=refkeys[h.seed,h.reference]
 for unit in ['pair','cell']:
  for metric in ['AP','BCE']:
   match=old[(old.seed==h.seed)&(old.method==h.method)&(old.reference==h.reference)&(old.epoch==h.epoch)&(old.unit==unit)&(old.metric==metric)] if h.condition=='COLD' else old.iloc[:0]
   comparisons.append(dict(section='A_simple',seed=h.seed,method=h.method,condition=h.condition,reference=h.reference,role='first_hit',epoch=int(h.epoch),tag='original',unit=unit,metric=metric,candidate_key=ck,reference_key=rk,old_low=float(match.iloc[0].loss_low) if len(match) else None,old_high=float(match.iloc[0].loss_high) if len(match) else None,old_status=str(match.iloc[0].status_5pct) if len(match) else None))
# Direct selected complete-predictor comparisons, in addition to original fixed targets.
for seed in F['seeds']:
 for ref,graph in [('HERMES','M4'),('MOCO','M5')]:
  g=next((x for x in result if x['seed']==seed and x['reference']==ref and x['method']==graph and x['validation_selected']),None)
  for method in ['M3','M2']:
   c=next((x for x in result if x['seed']==seed and x['reference']==ref and x['method']==method and x['validation_selected']),None)
   if c is None or g is None:continue
   for unit in ['pair','cell']:
    for metric in ['AP','BCE']:comparisons.append(dict(section='B_selected_direct',seed=seed,method=method,tag=c['tag'],reference=ref,reference_tag=g['tag'],role='validation_selected_direct',epoch=c['epoch'],reference_epoch=g['epoch'],candidate_key=c['candidate_key'],reference_key=g['candidate_key'],validation_selected=True,condition='REUSE',unit=unit,metric=metric))
pd.DataFrame(result).to_csv(R/'RESULTS_LONG.csv',index=False);pd.DataFrame(cost).to_csv(R/'COST_DECOMPOSITION.csv',index=False)
pd.DataFrame(comparisons).to_csv(R/'COMPARISONS.csv',index=False)
np.savez_compressed(R/'inputs/test_predictions.npz',**pred);np.savez(R/'inputs/test_rows.npz',rows=rows[te]);dump(R/'PREDICTOR_IDENTITIES.json',dict(input_hashes_file='INPUT_HASHES.json',validation_selection_sha256=sha(R/'VALIDATION_SELECTION.json'),predictors=identities,training_runs=[dict(run=c['run'],training_sha256=sha(Path(c['run'])/'TRAINING.json'),trajectory_sha256=sha(Path(c['run'])/'TRAJECTORY.jsonl'),cache_sha256=sha(S/'cache'/f"{c['method'] if c['method'] in ('M4','M5') else 'M0'}.pt")) for c in configs[::2]]))
print('Collected',len(result),'configuration-target rows;',len(pred),'distinct predictors',flush=True)
