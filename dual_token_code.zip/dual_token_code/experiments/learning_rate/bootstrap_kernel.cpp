#include <cstdint>
#include <cmath>
#include <vector>
extern "C" void evaluate(int B,int N,int P,const int16_t* weights,const int64_t* groups,const double* y,const double* z,const int64_t* order,double* output){
 std::vector<double> losses(N);
 for(int i=0;i<N;i++)losses[i]=fmax(z[i],0.)+log1p(exp(-fabs(z[i])))-y[i]*z[i];
 for(int b=0;b<B;b++){
  const int16_t* w=weights+(int64_t)b*P;
  double tp=0,total=0,previous_tp=0,ap=0,bce=0;
  for(int k=0;k<N;k++){
   int i=order[k];double count=w[groups[i]];tp+=count*y[i];total+=count;
   bce+=count*losses[i];
   if(k==N-1 || z[order[k+1]]!=z[i]){if(total>0)ap+=(tp-previous_tp)*tp/total;previous_tp=tp;}
  }
  output[b*2]=tp>0?ap/tp:NAN;output[b*2+1]=total>0?bce/total:NAN;
 }
}
