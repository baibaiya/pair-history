"""Read-only reconstruction of archived development evidence; new outputs only."""
import os
for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'): os.environ[k]='1'
import sys,json,hashlib,shutil,datetime
from pathlib import Path
import numpy as np
import pandas as pd
R=Path(__file__).resolve().parents[1]
S=R.parent/'dual_token_supplement_20261002'; O=R.parent/'dual_token_submission_20261002'
sys.path.insert(0,str(R/'source_snapshot'))
from predictors import construct,finish
from core import data,SEEDS,SPLITS,queries
from canonical_metrics import canonical_metrics as metrics
from early_intervals import ordered_ap
INPUT={}
def sha(p):
 p=Path(p); h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
 return h.hexdigest()
def track(p):
 p=Path(p).resolve();h=sha(p);INPUT[str(p)]=dict(sha256=h,bytes=p.stat().st_size);return h
def js(p):track(p);return json.loads(Path(p).read_text())
def dump(p,v):Path(p).write_text(json.dumps(v,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
def csv(n,rows):pd.DataFrame(rows).to_csv(R/n,index=False)
def loadpred(cp):
 p=cp/'predictions.npz';track(p)
 with np.load(p) as z:return {k:z[k] for k in z.files}
def passes(m,t):return m['AP']>=.95*t['AP'] and m['BCE']<=1.05*t['BCE']
def screening(m,t):return all(m[k]>=.95*t[k] for k in ['cell_P3','cell_P10pct','partner_P3','partner_P10pct'])
def ident(cp):
 aux=cp/('auxiliary.npz' if (cp/'auxiliary.npz').exists() else 'relation.npz')
 return dict(checkpoint=str(cp),weight_path=str(cp/'model.pt'),weight_sha256=track(cp/'model.pt'),weight_present=(cp/'model.pt').is_file(),prediction_path=str(cp/'predictions.npz'),prediction_sha256=track(cp/'predictions.npz'),auxiliary_path=str(aux) if aux.exists() else None,auxiliary_sha256=track(aux) if aux.exists() else None)
def boot6(pred,y,rows,unit='pair'):
 groups=np.unique(rows[:,:2] if unit=='pair' else rows[:,2:3],axis=0,return_inverse=True)[1];N=np.bincount(groups);P=len(N);rng=np.random.default_rng(20261002)
 weights=np.array([np.bincount(rng.integers(P,size=P),minlength=P) for _ in range(2000)],dtype=np.int16);out={};q=queries(rows)
 for key,z in pred.items():
  a=np.empty((2000,6));ap=ordered_ap(z,y);loss=np.bincount(groups,weights=np.logaddexp(0,z)-y*z,minlength=P);a[:,1]=(weights@loss)/(weights@N)
  for b,w in enumerate(weights):a[b,0]=ap(w[groups].astype(float))
  for kind,start in [('cell',2),('partner',4)]:
   nums=np.zeros((2000,2));den=np.zeros(2000)
   for ix in q[kind].values():
    ix=ix[np.lexsort((rows[ix,2],rows[ix,1],rows[ix,0]))];ix=ix[np.argsort(-z[ix],kind='stable')]
    if unit=='cell':
     w=weights[:,groups[ix[0]]];den+=w
     for j,k in enumerate([min(3,len(ix)),max(1,int(np.ceil(.1*len(ix))))]):nums[:,j]+=w*y[ix[:k]].mean()
    else:
     w=weights[:,groups[ix]];total=w.sum(1);cum=np.cumsum(w,axis=1);before=cum-w;den+=(total>0)
     for j,k in enumerate([np.minimum(3,total),np.maximum(1,np.ceil(.1*total).astype(int))]):
      hits=(np.minimum(w,np.maximum(0,k[:,None]-before))*y[ix]).sum(1);nums[:,j]+=np.divide(hits,k,out=np.zeros(2000),where=k>0)
   a[:,start:start+2]=np.divide(nums,den[:,None],out=np.full_like(nums,np.nan),where=den[:,None]>0)
  out[key]=a
 return out,weights
MET=['AP','BCE','cell_P3','cell_P10pct','partner_P3','partner_P10pct']
def main():
 assert not (R/'QUALITY_COST_LONG.csv').exists(),'Use a fresh destination; never overwrite completed analysis'
 (R/'predictions').mkdir();(R/'bootstrap').mkdir();(R/'state').mkdir()
 for folder in [S,O]:
  for p in folder.glob('*'):
   if p.is_file() and p.suffix in ('.json','.csv','.txt','.md') and p.stat().st_size<30_000_000:track(p)
 for p in (R/'source_snapshot').glob('*.py'):track(p)
 curves=[];roles=[];ids=[];ttq=[];runs=[];ab=[];states=[];gains=[];intervals=[];coverage=[];alignment=[];ties=[]
 prediction_pools={}; points={}; comparisons=[];ab_comparisons=[]
 for ds in ['GDSC','NCI','ONEIL']:
  rows,tr,vb,vs,vc,te=data(ds);track(SPLITS[ds]);assert not set(tr)&set(te);assert not set(tr)&set(vb)|set(tr)&set(vs)|set(tr)&set(vc)
  train_obj=set(rows[tr,:2].astype(int).ravel());train_context=set(rows[tr,2].astype(int));pairs,pid=np.unique(rows[:,:2].astype(int),axis=0,return_inverse=True);counts=np.bincount(pid[tr],minlength=len(pairs))
  coverage.append(dict(dataset=ds,rows=len(rows),train=len(tr),test=len(te),test_known_objects=bool(all(int(o) in train_obj for o in rows[te,:2].ravel())),test_known_contexts=bool(all(int(c) in train_context for c in rows[te,2])),test_supported_fraction=float(np.mean(counts[pid[te]]>0)),unique_pair_context=bool(len(np.unique(rows[:,:3],axis=0))==len(rows)),support_sha256=hashlib.sha256(tr.astype(np.int64).tobytes()).hexdigest()))
  prediction_pools[ds]={};points[ds]={}
  def register(cp):
   key=str(cp);pr=loadpred(cp);z=pr['final'][te]
   prediction_pools[ds][key]=z;points[ds][key]=metrics(z,rows[te,4],rows[te]);return key
  for seed in SEEDS:
   refs={}
   for ref in ['HERMES','MOCO']:
    src=O/'runs'/ds/str(seed)/ref;sel=js(src/'SELECTED.json');cp=src/f"checkpoint_{sel['epoch']}";pr=loadpred(cp)
    refs[ref]=dict(epoch=sel['epoch'],validation=metrics(pr['final'][vs],rows[vs,4],rows[vs]),test=metrics(pr['final'][te],rows[te,4],rows[te]),key=register(cp))
   conditions=['COLD','REUSE'] if ds=='GDSC' else ['COLD_LEGACY']
   ab_targets={}
   for condition in conditions:
    for method in ['q4','HERMES','MOCO']:
     src=S/'runs'/condition/str(seed)/{'q4':'M3','HERMES':'M4','MOCO':'M5'}[method] if ds=='GDSC' else O/'runs'/ds/str(seed)/{'q4':'Q4','HERMES':'HERMES','MOCO':'MOCO'}[method]
     track(src/'TRAJECTORY.jsonl');hist=[json.loads(l) for l in (src/'TRAJECTORY.jsonl').read_text().splitlines()];sel=js(src/'SELECTED.json');train=js(src/'TRAINING.json');assert sel['epoch']==max(hist,key=lambda h:(h['metrics']['AP'],-h['epoch']))['epoch']
     runs.append(dict(dataset=ds,condition=condition,seed=seed,method=method,full_run_seconds=train['wall_seconds'],full_process_seconds=train.get('process_seconds'),observed_checkpoints=len(hist),updates=train['updates'],trajectory=str(src/'TRAJECTORY.jsonl'),trajectory_sha256=track(src/'TRAJECTORY.jsonl')))
     hs=[]
     for h in hist:
      cp=src/f"checkpoint_{h['epoch']}";pr=loadpred(cp);v=metrics(pr['final'][vs],rows[vs,4],rows[vs]);t=metrics(pr['final'][te],rows[te,4],rows[te]);identity=ident(cp)
      for k in ['AP','BCE']:assert abs(v[k]-h['metrics'][k])<1e-12,(cp,k)
      for k in MET[2:]:
       if abs(v[k]-h['metrics'][k])>=1e-12:ties.append(dict(checkpoint=str(cp),metric=k,raw_log_value=h['metrics'][k],canonical_replay_value=v[k],reason='existing canonical tie repair; preserve measured log'))
      assert np.allclose(pr['final'],pr['calibration'][0]*pr['pre']+pr['calibration'][1],rtol=0,atol=1e-12)
      item=dict(dataset=ds,condition=condition,seed=seed,method=method,epoch=h['epoch'],pipeline_seconds=h['complete_seconds'],process_seconds=h.get('process_seconds'),time_status='measured',time_boundary='common imports complete; before method imports/input preparation',subphase_status='measured detailed' if ds=='GDSC' else 'preparation aggregate only; import startup and REUSE missing',selected_final=h['epoch']==sel['epoch'],final_selection_budget_seconds=train['wall_seconds'] if h['epoch']==sel['epoch'] else None,**identity,**{'val_'+k:v[k] for k in MET},**{'test_'+k:t[k] for k in MET},**{'phase_'+k:x for k,x in h['phase'].items()})
      curves.append(item);ids.append({k:item[k] for k in ['dataset','condition','seed','method','epoch',*identity.keys()]});hs.append((h,v,t,cp))
     for ref,target in refs.items():
      flags=[passes(v,target['validation']) for h,v,t,cp in hs];hit=next((i for i,f in enumerate(flags) if f),None)
      for role in ['first_hit','selected_final']:
       i=hit if role=='first_hit' else next(i for i,(h,v,t,cp) in enumerate(hs) if h['epoch']==sel['epoch'])
       record=dict(dataset=ds,condition=condition,seed=seed,method=method,reference=ref,role=role,reference_epoch=target['epoch'],reached=hit is not None,maintained_after_first=bool(all(flags[hit:])) if hit is not None else False,full_run_seconds=train['wall_seconds'],full_process_seconds=train.get('process_seconds'))
       if i is None:record.update(epoch=None,pipeline_seconds=None,process_seconds=None,validation_primary_pass=False,test_primary_pass=False,test_screening_pass=False)
       else:
        h,v,t,cp=hs[i];key=register(cp);record.update(epoch=h['epoch'],pipeline_seconds=h['complete_seconds'],process_seconds=h.get('process_seconds'),selection_budget_seconds=train['wall_seconds'] if role=='selected_final' else h['complete_seconds'],validation_primary_pass=passes(v,target['validation']),test_primary_pass=passes(t,target['test']),test_screening_pass=screening(t,target['test']),**{'test_'+k:t[k] for k in MET},**ident(cp));comparisons.append(dict(**{k:record[k] for k in ['dataset','condition','seed','method','reference','role','epoch']},candidate_key=key,reference_key=target['key']))
        if method=='q4':ab_targets.setdefault(cp,[]).append(dict(condition=condition,reference=ref,role=role))
       ttq.append(record)
   for cp,instance_roles in ab_targets.items():
    # COLD/REUSE identical q4 checkpoints reuse the COLD instance by actual raw/pre/final identity.
    pr=loadpred(cp);ep=int(cp.name.split('_')[1]);src_id=ident(cp)
    existing=next((a for a in alignment if a['dataset']==ds and a['seed']==seed and a['epoch']==ep and a['prediction_sha256']==src_id['prediction_sha256']),None)
    if existing:
     existing['roles'].extend(instance_roles);continue
    key=f'{ds}_{seed}_{ep}';dest=R/'predictions'/key;dest.mkdir();stpath=cp/('auxiliary.npz' if (cp/'auxiliary.npz').exists() else 'relation.npz');track(stpath)
    with np.load(stpath) as ff:st={k:ff[k] for k in ff.files}
    bt=st['base_theta'] if 'base_theta' in st else st['theta'];base=bt[0]*pr['raw']+bt[1];finaltheta=pr['calibration'];ps={};reuse=[]
    for m in ['M0','M1','M2','M3']:
     other=(cp.parents[1]/m/cp.name) if ds=='GDSC' else (S/'replay'/ds/str(seed)/m/cp.name)
     if (other/'predictions.npz').exists():
      pp=loadpred(other);np.testing.assert_array_equal(pp['raw'],pr['raw']);z=pp['pre'];auxp=other/'auxiliary.npz';track(auxp)
      with np.load(auxp) as f:aux={k:f[k] for k in f.files}
      np.testing.assert_array_equal(aux['base_theta'],bt);reuse.append(str(other))
     else:z,aux=construct(pr['raw'],rows,tr,vb,vc,m,bt)
     ps[m]=finaltheta[0]*z+finaltheta[1]
     np.savez(dest/f'{m}_auxiliary.npz',**aux,final_theta=finaltheta)
     if m=='M1':prior_aux=aux
     # Separately calibrated whole-predictor comparison is retained, never substituted for fixed calibration.
     sec=pp['final'] if (other/'predictions.npz').exists() else finish(z,rows,vc)[0]
     ab.append(dict(instance=key,dataset=ds,seed=seed,epoch=ep,method=m,calibration='method_specific_V_cal_sensitivity',**metrics(sec[te],rows[te,4],rows[te])))
    np.testing.assert_allclose(ps['M3'],pr['final'],rtol=0,atol=1e-12)
    n=st['support'];codes=st['codes'].copy();bins=np.digitize(n,[1,5,16]);rng=np.random.default_rng(20260928)
    for b in np.unique(bins):
     ix=np.flatnonzero(bins==b);codes[ix]=codes[rng.permutation(ix)]
    assert np.array_equal(codes<0,st['codes']<0)
    off=np.where(codes>=0,st['centers'][codes.clip(0)],0.)
    ps['SHUFFLE']=finaltheta[0]*(base+off[st['pid']])+finaltheta[1]
    np.savez(dest/'predictions.npz',**ps);np.savez(dest/'shuffle_state.npz',codes=codes,bins=bins,centers=st['centers'],support=n,seed=20260928)
    alignment.append(dict(instance=key,dataset=ds,seed=seed,epoch=ep,roles=instance_roles,**src_id,reused= reuse,base_theta=bt.tolist(),final_theta=finaltheta.tolist(),new_prediction_path=str(dest/'predictions.npz'),support_sha256=coverage[-1]['support_sha256']))
    for m,z in ps.items():
     k=key+'/'+m;prediction_pools[ds][k]=z[te];points[ds][k]=metrics(z[te],rows[te,4],rows[te]);ab.append(dict(instance=key,dataset=ds,seed=seed,epoch=ep,method=m,calibration='fixed_q4_base_and_final',**points[ds][k]))
    ab_comparisons.append(dict(instance=key,dataset=ds,seed=seed,epoch=ep))
    # Actual minimal numeric inference files; model checkpoint includes object buffers/features.
    common=R/'state'/key;common.mkdir();rows[:,:3].astype('<i4').tofile(common/'coverage.bin');np.r_[bt,finaltheta].astype('<f8').tofile(common/'calibration.bin')
    common_bytes=(cp/'model.pt').stat().st_size+sum(p.stat().st_size for p in common.iterdir())
    for m in ['M0','M1','M2','M3']:
     d=common/m;d.mkdir()
     if m!='M0':
      st['pairs'].astype('<i4').tofile(d/'pair_addresses.bin');np.packbits(n>0,bitorder='little').tofile(d/'supported.bin')
     if m=='M1':
      prior_aux['prior_logit'].astype('<f8').tofile(d/'prior.bin');prior_aux['beta'].astype('<f8').tofile(d/'beta.bin');np.array([prior_aux['tau'],prior_aux['global_prevalence']],dtype='<f8').tofile(d/'build_parameters.bin')
     if m=='M2':st['continuous'].astype('<f8').tofile(d/'offsets.bin')
     if m=='M3':
      cc=st['codes'].clip(0).astype(np.uint8);packed=np.packbits(((cc[:,None]>>np.arange(4))&1).ravel(),bitorder='little');packed.tofile(d/'codes.bin');st['centers'].astype('<f8').tofile(d/'centers.bin')
      unpack=np.unpackbits(packed,bitorder='little')[:len(cc)*4].reshape(-1,4)@(2**np.arange(4));np.testing.assert_array_equal(unpack,cc)
     numeric=sum(p.stat().st_size for p in d.iterdir());states.append(dict(instance=key,dataset=ds,seed=seed,epoch=ep,method=m,weight_bytes=(cp/'model.pt').stat().st_size,common_bytes=common_bytes,relation_and_parameters_bytes=numeric,full_predictor_bytes=common_bytes+numeric,pair_count=len(n),state_scope='checkpoint including feature buffers + legal coverage + calibrations + pair address/support/values; excludes diagnostic arrays and query acceleration indexes; no service claim'))
  print('CURVES_AND_ABLATIONS',ds,flush=True)
 # Emit reconstruction before bootstrap for inspectability; not final seal.
 csv('SCREENING_TIE_AUDIT.csv',ties);csv('QUALITY_COST_LONG.csv',curves);csv('MODEL_IDENTITIES.csv',ids);csv('TIME_TO_QUALITY.csv',ttq);csv('RUN_BUDGETS.csv',runs);csv('ABLATION.csv',ab);csv('FULL_STATE.csv',states);dump(R/'FORMAL_Q4_INSTANCES.json',alignment);dump(R/'TASK_COVERAGE.json',coverage)
 dump(R/'INPUTS_LOCK.json',INPUT)
 for ds in prediction_pools:
  rows,tr,vb,vs,vc,te=data(ds);pool=prediction_pools[ds]
  # Deduplicate exact model outputs for compute only; identities remain distinct in all tables.
  unique={};aliases={};hashes={}
  for k,z in pool.items():
   h=hashlib.sha256(z.tobytes()).hexdigest()
   if h not in hashes:hashes[h]=k;unique[k]=z
   aliases[k]=hashes[h]
  for unit in ['pair','cell']:
   draws,w=boot6(unique,rows[te,4],rows[te],unit);np.savez_compressed(R/'bootstrap'/f'{ds}_{unit}.npz',**{str(i):v for i,v in enumerate(draws.values())},multiplicities=w);dump(R/'bootstrap'/f'{ds}_{unit}_keys.json',dict(keys=list(draws),aliases=aliases,metrics=MET))
   for c in [c for c in comparisons if c['dataset']==ds]:
    a=draws[aliases[c['candidate_key']]];b=draws[aliases[c['reference_key']]];pa=points[ds][c['candidate_key']];pb=points[ds][c['reference_key']]
    for j,m in enumerate(MET):
     rel=a[:,j]/b[:,j]-1 if m=='BCE' else 1-a[:,j]/b[:,j];val=pa[m]/pb[m]-1 if m=='BCE' else 1-pa[m]/pb[m];lo,hi=np.nanquantile(rel,[.025,.975]);intervals.append(dict(**c,unit=unit,metric=m,candidate=pa[m],reference_value=pb[m],relative_loss=val,loss_low=lo,loss_high=hi,point_pass=val<=.05,status='confirmed' if hi<=.05 else ('confirmed_degradation' if lo>.05 else 'unconfirmed')))
   for c in [c for c in ab_comparisons if c['dataset']==ds]:
    key=c['instance'];aa={m:draws[aliases[key+'/'+m]] for m in ['M0','M1','M2','M3','SHUFFLE']};pp={m:points[ds][key+'/'+m] for m in aa}
    for j,m in enumerate(MET):
     sign=-1 if m=='BCE' else 1;qgain=sign*(pp['M3'][m]-pp['M0'][m]);fgain=sign*(pp['M2'][m]-pp['M0'][m]);pgain=sign*(pp['M1'][m]-pp['M0'][m]);qd=sign*(aa['M3'][:,j]-aa['M0'][:,j]);fd=sign*(aa['M2'][:,j]-aa['M0'][:,j]);lo,hi=np.nanquantile(qd,[.025,.975]);sl,sh=np.nanquantile(sign*(aa['M3'][:,j]-aa['SHUFFLE'][:,j]),[.025,.975]);difflo,diffhi=np.nanquantile(sign*(aa['M3'][:,j]-aa['M2'][:,j]),[.025,.975]);plo,phi=np.nanquantile(sign*(aa['M1'][:,j]-aa['M0'][:,j]),[.025,.975]);flo,fhi=np.nanquantile(fd,[.025,.975])
     gains.append(dict(**c,unit=unit,metric=m,q4_gain=qgain,q4_gain_low=lo,q4_gain_high=hi,float_gain=fgain,float_gain_low=flo,float_gain_high=fhi,prior_gain=pgain,prior_gain_low=plo,prior_gain_high=phi,q4_retained_float_gain=qgain/fgain if fgain>0 else None,retention_interval_defined=bool(flo>0),retention_low=float(np.quantile(qd/fd,.025)) if flo>0 and np.all(fd>0) else None,retention_high=float(np.quantile(qd/fd,.975)) if flo>0 and np.all(fd>0) else None,q4_minus_float_gain=sign*(pp['M3'][m]-pp['M2'][m]),q4_minus_float_low=difflo,q4_minus_float_high=diffhi,q4_minus_shuffle_gain=sign*(pp['M3'][m]-pp['SHUFFLE'][m]),q4_minus_shuffle_low=sl,q4_minus_shuffle_high=sh))
   print('BOOTSTRAP',ds,unit,'unique_predictors',len(unique),flush=True)
 csv('QUALITY_INTERVALS.csv',intervals);csv('ABLATION_GAINS.csv',gains);dump(R/'INPUTS_LOCK.json',INPUT)
 dump(R/'BUILD_COMPLETE.json',dict(time=datetime.datetime.now(datetime.timezone.utc).isoformat(),curves=len(curves),formal_instances=len(alignment),intervals=len(intervals),ablation_rows=len(ab),no_training=True))
if __name__=='__main__':main()
