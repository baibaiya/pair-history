"""Fixed-predictor paired cluster resampling (2,000 draws)."""
import numpy as np
from .metrics import queries

def ordered_ap(z,y):
 order=np.argsort(-z,kind='stable');zz=z[order];yy=y[order];ends=np.r_[np.flatnonzero(zz[1:]!=zz[:-1]),len(zz)-1]
 def calc(w):
  w=w[order];tp=np.cumsum(w*yy)[ends];total=np.cumsum(w)[ends]
  if not tp[-1]:return np.nan
  return float(np.sum(np.diff(np.r_[0,tp])*np.divide(tp,total,out=np.zeros_like(tp),where=total>0))/tp[-1])
 return calc

def boot6(pred,y,rows,unit='pair'):
 groups=np.unique(rows[:,:2] if unit=='pair' else rows[:,2:3],axis=0,return_inverse=True)[1];N=np.bincount(groups);P=len(N);rng=np.random.default_rng(20261002)
 weights=np.array([np.bincount(rng.integers(P,size=P),minlength=P) for _ in range(2000)],dtype=np.int16);out={};q=queries(rows)
 for key,z in pred.items():
  a=np.empty((2000,6));ap=ordered_ap(z,y);loss=np.bincount(groups,weights=np.logaddexp(0,z)-y*z,minlength=P);a[:,1]=(weights@loss)/(weights@N)
  for b,w in enumerate(weights):a[b,0]=ap(w[groups].astype(float))
  for kind,start in [('cell',2),('partner',4)]:
   nums=np.zeros((2000,2));den=np.zeros(2000)
   for ix in q[kind].values():
    ix=ix[np.lexsort((rows[ix,2],rows[ix,1],rows[ix,0]))];ix=ix[np.argsort(-z[ix],kind='stable')]
    if unit=='cell':
     w=weights[:,groups[ix[0]]];den+=w
     for j,k in enumerate([min(3,len(ix)),max(1,int(np.ceil(.1*len(ix))))]):nums[:,j]+=w*y[ix[:k]].mean()
    else:
     w=weights[:,groups[ix]];total=w.sum(1);cum=np.cumsum(w,axis=1);before=cum-w;den+=(total>0)
     for j,k in enumerate([np.minimum(3,total),np.maximum(1,np.ceil(.1*total).astype(int))]):
      hits=(np.minimum(w,np.maximum(0,k[:,None]-before))*y[ix]).sum(1);nums[:,j]+=np.divide(hits,k,out=np.zeros(2000),where=k>0)
   a[:,start:start+2]=np.divide(nums,den[:,None],out=np.full_like(nums,np.nan),where=den[:,None]>0)
  out[key]=a
 return out,weights
