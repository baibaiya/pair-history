"""AP, BCE and deterministic screening metrics."""
import numpy as np
from scipy.special import expit
from sklearn.metrics import average_precision_score

def queries(rows):
 groups={'cell':{},'partner':{}}
 for i,(a,b,c) in enumerate(rows[:,:3].astype(int)):
  groups['cell'].setdefault(str(c),[]).append(i)
  for obj in set((a,b)):groups['partner'].setdefault(f'{c}:{obj}',[]).append(i)
 return {kind:{k:np.array(v) for k,v in qs.items()} for kind,qs in groups.items()}

def metrics(z,y,rows=None):
 p=expit(z);pos=y.sum();result={'AP':float(average_precision_score(y,z)) if pos else None,'BCE':float(np.mean(np.logaddexp(0,z)-y*z)),'error05':float(np.mean((p>=.5)!=y)),'recall05':float(np.sum((p>=.5)*y)/pos) if pos else None,'n':len(y)}
 if rows is not None:
  for kind,qs in queries(rows).items():
   for label in ('3','10pct'):
    ps=[];rs=[]
    for ix in qs.values():
     k=min(3,len(ix)) if label=='3' else max(1,int(np.ceil(.1*len(ix))))
     rank=ix[np.argsort(-z[ix],kind='stable')[:k]];hit=y[rank].sum();ps.append(hit/k)
     if y[ix].sum():rs.append(hit/y[ix].sum())
    result[f'{kind}_P{label}']=float(np.mean(ps)) if ps else None
    result[f'{kind}_R{label}']=float(np.mean(rs)) if rs else None
 return result

def canonical_metrics(z,y,rows=None):
 if rows is not None:
  order=np.lexsort((rows[:,2],rows[:,1],rows[:,0]))
  z,y,rows=z[order],y[order],rows[order]
 return original_metrics(z,y,rows)

original_metrics = metrics
