import torch
class ObjectModel(torch.nn.Module):
    def __init__(self,drug,cell):
        super().__init__()
        self.register_buffer('drug',torch.tensor(drug,dtype=torch.float32))
        self.register_buffer('cell',torch.tensor(cell,dtype=torch.float32))
        self.net=torch.nn.Sequential(torch.nn.Linear(drug.shape[1]*2+cell.shape[1],512),torch.nn.ReLU(),
            torch.nn.Dropout(.10),torch.nn.Linear(512,128),torch.nn.ReLU(),torch.nn.Linear(128,1))
    def forward(self,x):
        a,b,c=x[:,0].long(),x[:,1].long(),x[:,2].long()-self.drug.shape[0]
        return self.net(torch.cat((self.drug[a],self.drug[b],self.cell[c]),1)).squeeze(1)
