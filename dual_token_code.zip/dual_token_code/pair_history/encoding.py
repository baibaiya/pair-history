"""Little-endian packing; support markers are stored separately."""
import numpy as np

def pack(codes,B):
 values=codes.clip(0).astype(np.uint16);bits=((values[:,None]>>np.arange(B))&1).astype(np.uint8).ravel();return np.packbits(bits,bitorder='little')
