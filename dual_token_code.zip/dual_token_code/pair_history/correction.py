"""Pair residuals, loss-based codes, historical prior and affine calibration."""
import time
import numpy as np
from scipy.special import expit, logit
from scipy.optimize import minimize
from .metrics import canonical_metrics as metrics
GLOBAL_PREVALENCE = [None]

def calibrate(z,y):
 def fn(w):
  v=w[0]*z+w[1];e=expit(v)-y;d=w-np.array([1.,0.])
  return float(np.mean(np.logaddexp(0,v)-y*v)+.5*(d@d)/len(y)),np.array([e@z,e.sum()])/len(y)+d/len(y)
 o=minimize(fn,[1.,0.],jac=True,method='L-BFGS-B',bounds=[(1e-6,None),(None,None)],options={'maxiter':1000,'ftol':1e-14,'gtol':1e-9})
 assert np.isfinite(o.x).all()
 return o.x

def continuous(pid,y,base,P):
 n=np.bincount(pid,minlength=P);lo=-n.astype(float);hi=n.astype(float)
 for _ in range(80):
  m=(lo+hi)/2;g=np.bincount(pid,weights=expit(base+m[pid])-y,minlength=P)+m
  lo=np.where(g<0,m,lo);hi=np.where(g>=0,m,hi)
 return (lo+hi)/2,n

def quantize(v,n,pid,y,base,B):
 K=2**B;values=v[n>0];edges=np.quantile(values,np.linspace(0,1,K+1));bins=np.searchsorted(edges[1:-1],values,side='right');den=np.bincount(bins,minlength=K)
 centers=np.divide(np.bincount(bins,weights=values,minlength=K),den,out=np.zeros(K),where=den>0)
 costs=np.empty((len(n),K))
 for j,d in enumerate(centers):costs[:,j]=np.bincount(pid,weights=np.logaddexp(0,base+d)-y*(base+d),minlength=len(n))+.5*d*d
 codes=costs.argmin(1).astype(np.int16);codes[n==0]=-1
 return np.where(n>0,centers[codes.clip(0)],0.),codes,centers

def rawlog(p): return logit(np.clip(np.asarray(p,dtype=float),1e-7,1-1e-7))

def build(raw,rows,tr,vb):
 t=time.perf_counter();pairs,pid=np.unique(rows[:,:2].astype(int),axis=0,return_inverse=True);theta=calibrate(raw[vb],rows[vb,4]);base=theta[0]*raw+theta[1];cal_seconds=time.perf_counter()-t;t=time.perf_counter()
 v,n=continuous(pid[tr],rows[tr,4],base[tr],len(pairs));off,codes,centers=quantize(v,n,pid[tr],rows[tr,4],base[tr],4)
 return base+off[pid],dict(base=base,continuous=v,support=n,pairs=pairs,pid=pid,codes=codes,centers=centers,theta=theta,internal_calibration_seconds=cal_seconds,relation_seconds=time.perf_counter()-t)

def construct(raw,rows,tr,vb,vc,method,base_theta=None):
 y=rows[:,4];theta=calibrate(raw[vb],y[vb]) if base_theta is None else base_theta
 base=theta[0]*raw+theta[1];st={'base_theta':theta};z=base
 if method in ('M1','M2','M3'):
  pairs,pid=np.unique(rows[:,:2].astype(int),axis=0,return_inverse=True);P=len(pairs);n=np.bincount(pid[tr],minlength=P)
  st.update(pairs=pairs,pid=pid,support=n)
  if method=='M1':
   # The global prevalence fallback is supplied from the full training population only at budget zero.
   gp=y[tr].mean() if len(tr) else float(GLOBAL_PREVALENCE[0]);s=np.bincount(pid[tr],weights=y[tr],minlength=P)
   taus=[1,4,16,64,256];priors={t:(s+t*gp)/(n+t) for t in taus};tau=min(taus,key=lambda t:metrics(rawlog(priors[t][pid[vb]]),y[vb])['BCE'])
   pr=rawlog(priors[tau]);X=np.column_stack((np.ones(len(rows)),base,pr[pid]))
   def fn(b):
    v=X[vb]@b;e=expit(v)-y[vb]
    return float(np.sum(np.logaddexp(0,v)-y[vb]*v)+.5*b@b),X[vb].T@e+b
   fit=minimize(fn,[0,1,0],jac=True,method='L-BFGS-B',options={'maxiter':1000,'ftol':1e-13,'gtol':1e-7})
   assert fit.success or np.linalg.norm(fit.jac)<1e-4
   z=X@fit.x;st.update(tau=tau,beta=fit.x,prior_logit=pr,global_prevalence=gp)
  else:
   v,n=continuous(pid[tr],y[tr],base[tr],P);st['continuous']=v
   if method=='M3' and len(tr):
    off,codes,centers=quantize(v,n,pid[tr],y[tr],base[tr],4);st.update(codes=codes,centers=centers)
   elif method=='M3':
    off=v;st.update(codes=np.full(P,-1,dtype=np.int16),centers=np.zeros(16))
   else:off=v
   z=base+off[pid]
 return z,st

def finish(z,rows,vc):
 theta=calibrate(z[vc],rows[vc,4]);return theta[0]*z+theta[1],theta
