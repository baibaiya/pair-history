import ctypes
import shutil
import subprocess
import tempfile
import unittest
from pathlib import Path

import numpy as np
from sklearn.metrics import average_precision_score


@unittest.skipUnless(shutil.which("g++"), "g++ is needed for the optional kernel test")
class KernelTest(unittest.TestCase):
    def test_kernel_matches_weighted_metrics(self):
        source = Path(__file__).resolve().parents[1] / "experiments/learning_rate/bootstrap_kernel.cpp"
        with tempfile.TemporaryDirectory() as tmp:
            library = Path(tmp) / "kernel.so"
            subprocess.run(
                ["g++", "-O3", "-std=c++17", "-shared", "-fPIC", str(source), "-o", str(library)],
                check=True, capture_output=True,
            )
            fn = ctypes.CDLL(str(library)).evaluate
            ptr = np.ctypeslib.ndpointer
            fn.argtypes = [
                ctypes.c_int, ctypes.c_int, ctypes.c_int,
                ptr(dtype=np.int16, flags="C_CONTIGUOUS"),
                ptr(dtype=np.int64, flags="C_CONTIGUOUS"),
                ptr(dtype=np.float64, flags="C_CONTIGUOUS"),
                ptr(dtype=np.float64, flags="C_CONTIGUOUS"),
                ptr(dtype=np.int64, flags="C_CONTIGUOUS"),
                ptr(dtype=np.float64, flags="C_CONTIGUOUS"),
            ]
            fn.restype = None
            y = np.tile([0., 1.], 5)
            z = np.array([0., 0., 0.5, 0.5, 1., -1., 2., 2., -2., -2.])
            groups = np.repeat(np.arange(5, dtype=np.int64), 2)
            rng = np.random.default_rng(20261002)
            weights = np.array([
                np.bincount(rng.integers(5, size=5), minlength=5) for _ in range(8)
            ], dtype=np.int16)
            order = np.argsort(-z, kind="stable").astype(np.int64)
            actual = np.empty((8, 2), dtype=np.float64)
            fn(8, len(y), 5, weights, groups, y, z, order, actual)
            expected = []
            for multiplicities in weights:
                w = multiplicities[groups].astype(float)
                expected.append([
                    average_precision_score(y, z, sample_weight=w),
                    np.sum(w * (np.logaddexp(0, z) - y * z)) / w.sum(),
                ])
            np.testing.assert_allclose(actual, expected, atol=2e-13, rtol=0)


if __name__ == "__main__":
    unittest.main()
