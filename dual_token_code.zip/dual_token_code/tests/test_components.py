import unittest
import numpy as np
from scipy.special import expit
from sklearn.metrics import average_precision_score

from pair_history.correction import (
    GLOBAL_PREVALENCE, calibrate, construct, continuous, finish, quantize,
)
from pair_history.encoding import pack
from pair_history.metrics import canonical_metrics
from pair_history.statistics import ordered_ap, boot6


class ComponentsTest(unittest.TestCase):
    def setUp(self):
        rng = np.random.default_rng(19)
        self.rows = np.array([
            [p, p + 5, c + 20, 0, (p + c) % 2]
            for p in range(5) for c in range(12)
        ], dtype=float)
        self.raw = rng.normal(size=len(self.rows))
        self.train = np.flatnonzero((self.rows[:, 2] < 26) & (self.rows[:, 0] < 4))
        self.build = np.flatnonzero((self.rows[:, 2] >= 26) & (self.rows[:, 2] < 28))
        self.cal = np.flatnonzero((self.rows[:, 2] >= 28) & (self.rows[:, 2] < 30))
        self.test = np.flatnonzero(self.rows[:, 2] >= 30)

    def test_residual_stationarity_and_unsupported_pair(self):
        pid = self.rows[:, 0].astype(int)
        y = self.rows[:, 4]
        v, n = continuous(pid[self.train], y[self.train], self.raw[self.train], 5)
        gradient = np.bincount(
            pid[self.train],
            weights=expit(self.raw[self.train] + v[pid[self.train]]) - y[self.train],
            minlength=5,
        ) + v
        np.testing.assert_allclose(gradient, 0, atol=1e-12)
        self.assertTrue(np.all(np.abs(v) <= n))
        self.assertEqual(v[-1], 0)

    def test_codes_minimize_recorded_loss(self):
        pid = self.rows[:, 0].astype(int)
        y = self.rows[:, 4]
        p, yy, b = pid[self.train], y[self.train], self.raw[self.train]
        v, n = continuous(p, yy, b, 5)
        offset, codes, centers = quantize(v, n, p, yy, b, 4)
        costs = np.column_stack([
            np.bincount(p, weights=np.logaddexp(0, b + c) - yy * (b + c),
                        minlength=5) + 0.5 * c * c
            for c in centers
        ])
        np.testing.assert_array_equal(codes[n > 0], costs.argmin(1)[n > 0])
        self.assertEqual(codes[-1], -1)
        self.assertEqual(offset[-1], 0)
        self.assertEqual(len(centers), 16)

    def test_pack_round_trip(self):
        for bits in [2, 3, 4, 8]:
            codes = np.array([-1, 0, 1, 2 ** bits - 1, 2])
            encoded = pack(codes, bits)
            decoded = np.unpackbits(encoded, bitorder="little")[:len(codes) * bits]
            decoded = decoded.reshape(-1, bits) @ (2 ** np.arange(bits))
            np.testing.assert_array_equal(decoded, codes.clip(0))
            self.assertEqual(encoded.nbytes, int(np.ceil(len(codes) * bits / 8)))

    def test_corrections_do_not_use_held_out_labels(self):
        for method in ["M0", "M1", "M2", "M3"]:
            score, state = construct(
                self.raw, self.rows, self.train, self.build, self.cal, method,
            )
            hidden = self.rows.copy()
            hidden[np.r_[self.cal, self.test], 4] = np.nan
            other, _ = construct(self.raw, hidden, self.train, self.build, self.cal, method)
            np.testing.assert_array_equal(score, other)
            final, theta = finish(score, self.rows, self.cal)
            self.assertGreater(theta[0], 0)
            np.testing.assert_allclose(final, theta[0] * score + theta[1])
            if method in ["M2", "M3"]:
                base = state["base_theta"][0] * self.raw + state["base_theta"][1]
                unsupported = self.rows[:, 0] == 4
                np.testing.assert_array_equal(score[unsupported], base[unsupported])

    def test_zero_history(self):
        GLOBAL_PREVALENCE[0] = float(self.rows[self.train, 4].mean())
        for method in ["M1", "M2", "M3"]:
            score, state = construct(
                self.raw, self.rows, np.array([], dtype=int), self.build, self.cal, method,
            )
            self.assertTrue(np.isfinite(score).all())
            if method == "M3":
                np.testing.assert_array_equal(state["codes"], -np.ones(5, dtype=int))
        GLOBAL_PREVALENCE[0] = None

    def test_weighted_ap_handles_ties(self):
        z = np.array([0.5, 0.5, 0.3, 0.3, -0.4, -0.7])
        y = np.array([0., 1., 1., 0., 1., 0.])
        w = np.array([2., 1., 3., 0., 1., 1.])
        self.assertAlmostEqual(
            ordered_ap(z, y)(w), average_precision_score(y, z, sample_weight=w), places=14,
        )

    def test_screening_is_invariant_to_input_order(self):
        z = np.zeros(len(self.rows))
        y = self.rows[:, 4]
        reverse = np.arange(len(z))[::-1]
        self.assertEqual(
            canonical_metrics(z, y, self.rows),
            canonical_metrics(z[reverse], y[reverse], self.rows[reverse]),
        )

    def test_bootstrap_identical_predictors_share_draws(self):
        ix = self.test
        pred = {"a": self.raw[ix], "b": self.raw[ix].copy()}
        for unit in ["pair", "cell"]:
            values, weights = boot6(pred, self.rows[ix, 4], self.rows[ix], unit)
            np.testing.assert_allclose(values["a"], values["b"], equal_nan=True)
            self.assertEqual(values["a"].shape, (2000, 6))
            self.assertTrue(np.all(weights.sum(axis=1) == weights.shape[1]))


if __name__ == "__main__":
    unittest.main()
