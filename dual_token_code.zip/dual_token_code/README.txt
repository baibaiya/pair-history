Pair-History Prediction: Code

This source-only package accompanies "Evaluating Pair History for Drug
Combination Prediction: Quality, Storage, and Construction Cost".
It does not include datasets, model weights, saved predictions or measured logs.
It is not, by itself, the complete experimental artifact for submission.

Contents
  pair_history/              Importable numerical components and object MLP.
  experiments/gdsc/          Original GDSC COLD/REUSE training and history analysis.
  experiments/cross_dataset/ Original cross-dataset trainer and bit-width study.
  experiments/learning_rate/ Configuration search and 50,000-draw interval code.
  experiments/matched_analysis/
                            Matched ablations, permutation and state accounting.
  experiments/saved_results/
                            Checks requiring saved results not included here.
  configs/                  Selected fields from the recorded experiment settings.
  tests/                    Small numerical checks; these are not paper experiments.
  SOURCE_MAP.csv            Sources, hashes and function-level extraction records.
  DATA_SOURCES.txt          External dataset versions, input files and preprocessing.

Quick check (CPU; no downloads or training)
  python -m pip install -r requirements.txt
  python -m unittest discover -s tests -v

Python 3.10 was used for the experiments. Importing pair_history.model additionally
requires PyTorch. The recorded training environment used PyTorch 2.6.0 with CUDA
12.4. Graph baselines also require their upstream dependencies, including
torch-geometric, RDKit and DeepChem. The fast bootstrap kernel requires g++ with
C++17 support. requirements.txt covers numerical analysis, not the graph stack.

Core interface
  from pair_history import construct, finish
  z, state = construct(raw, rows, train, build, calibration, "M3")
  final, theta = finish(z, rows, calibration)

raw contains base-model logits, not probabilities. rows has columns
[drug_a, drug_b, cell_id, synergy_score, binary_label]. Pairs are canonicalized
upstream. Index arrays refer to rows and must obey the original disjoint split.
M0 = calibrated Object, M1 = Prior, M2 = Float, M3 = q4.
For a zero-history Prior diagnostic, set correction.GLOBAL_PREVALENCE[0] to
the positive rate of the full training population, never the test population.
Unsupported pairs use zero residual; their stored code is -1.

construct returns an uncalibrated complete score and auxiliary arrays.
finish applies final calibration. Matched ablations instead reuse q4's base
and final calibration for all components, as shown in matched_analysis/build.py.
The returned auxiliary dictionary is not the packed inference-state format.
Main storage measurements include pair addressing, support, codebook, feature
buffers, weights, calibration and coverage. See matched_analysis/build.py.

Experiment sources
The experiments/ files are unchanged recorded sources, not portable launchers.
They retain original input paths, run layouts and provenance checks. They should
not be launched from this package without supplying those dependencies.
The configs/ extracts document settings; they do not replace the original
FREEZE.json files expected by the historical trainers.
Only relevant fields are retained. The explicit checkpoint list controls the
trainer; the stale, unused checkpoint_count field is deliberately omitted.

The GDSC and learning-rate trainers are retained separately because the latter
adds configuration control and logging inside the timed process. The
cross-dataset trainer uses the COLD-LEGACY boundary, not GDSC REUSE timing.
GDSC main comparisons use process_seconds; COLD-LEGACY uses complete_seconds.
Configuration search includes process exit and is accounted for separately.
Bit-width and history-size experiments use their own fixed object models.
Do not combine their checkpoints with the main matched-ablation checkpoints.

To reproduce full runs, supply the dataset inputs identified in DATA_SOURCES.txt,
the baseline versions in BASELINES.txt, and the run-specific inputs/checkpoints.
The scripts in saved_results/ require saved experimental outputs that are not
included in this package; they cannot verify the paper's reported results from
this source-only archive alone.
Missing times are not zero; recorded first-attainment times are not estimated
by subtracting preparation or calibration costs.

The numerical function bodies in pair_history/ were selected from the recorded
sources without changing their calculations. Imports were made local.
Original scripts are retained for tracing the complete experimental protocols.
